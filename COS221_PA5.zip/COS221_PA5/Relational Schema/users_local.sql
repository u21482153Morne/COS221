-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2023 at 06:09 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users_local`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `WineID` int(11) NOT NULL,
  `UserID` int(10) UNSIGNED NOT NULL,
  `Rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`WineID`, `UserID`, `Rating`) VALUES
(6, 7, 5),
(16, 7, 3);

-- --------------------------------------------------------
-- Table Structure for table 'customers'

CREATE Table `customers` (
`UserID` INT(11) UNSIGNED NOT NULL,
    `CustomerName` VARCHAR(50) NOT NULL,
    `PreferredWineType` TEXT(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customers` (`UserID`, `CustomerName`, `PreferredWineType`)
VALUES (7, 'Bouchaib', 'Red'),
       (8, 'Nada', 'White'),
       (9, 'Aicha', 'Red');


CREATE TABLE `expert` (
    `UserID` INT(11) UNSIGNED NOT NULL,
    `ExpertName` VARCHAR(50) NOT NULL,
    `Certification` TEXT(50) NOT NULL,
    `Organisation` TEXT(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `expert` (`UserID`,`ExpertName`,`Certification`,`Organisation`)
VALUES (8, 'Nada', 'IPA Connosieur', 'IPA Global');


CREATE TABLE `farm` (
    `FarmName` VARCHAR(50) NOT NULL,
    `Country` TEXT(50) NOT NULL,
    `Province` TEXT(50) NOT NULL,
    `Images` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `Farm` (`FarmName`, `Country`, `Province`, `Images`) VALUES
('Greensborough Estates', 'England', 'Birmingham', 'https://media.cntraveller.com/photos/611beddbd5b6f5a4a3def7fe/16:9/w_2992,h_1683,c_limit/2tillingham.jpg'),
('Rose Tinted', 'Namibia', 'Windhoek', 'https://www.namibia-info.com/info/categories/331/top_pic.jpg'),
('The Big bad Grape', 'South Africa', 'Limpopo', 'https://www.limpopo-info.co.za/info/categories/744/top_pic.jpg'),
('The Green Vinyard', 'Portugal', 'Porto', 'https://images.saymedia-content.com/.image/t_share/MTc0MTg5MjExMDQ0MzU4MDEy/wineries-in-portugal-for-beginners-portuguese-wine.jpg'),
('Winds of Napa Valley', 'United States of America', 'Napa Valley', 'https://static3.mansionglobal.com/production/media/article-images/0a2c7fce68fd99aa0961e1faea29ed32/large_1187.jpg');



CREATE TABLE `favouriteWines` (
	`UserID` INT(11) UNSIGNED NOT NULL,
    `WineID` INT(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `favouriteWines` (`UserID`, `WineID`) VALUES
(8, 3),
(7,15),
(9,24);

CREATE TABLE `accounts` (
	`AccountID` INT(11) NOT NULL,
    `Verfied` TINYINT(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    
INSERT INTO `Accounts` (`AccountID`, `Verified`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1);
    
CREATE TABLE `has`(
	`WineID` INT(11) NOT NULL,
    `Retailer Name` VARCHAR(50) NOT NULL,
    `Units` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `Has` (`WineID`, `RetailerName`, `Units`) VALUES
('5', 'NoWayRose', 155),
('15', 'TheWayItGoes', 109),
(32, 'WhoLetTheWinesOut', 55),
('50', 'WinesRUs', 209),
('45', 'WinesRUs', 300);



CREATE TABLE `imports` (
	`WineryID` INT(11) NOT NULL,
    `FarmName` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `imports` (`WineryID`,`FarmName`) VALUES
(1, 'Greensborough Estates'),
(2, 'The Big bad Grape'),
(3,'The Big bad Grape'),
(7,'Rose Tinted'),
(3,'The Green Vinyard');

CREATE TABLE `manager` (
	`UserID` INT(11) UNSIGNED NOT NULL,
    `ManagerName` VARCHAR(50) NOT NULL,
    `OwnedWinery` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `manager`(`UserID`,`ManagerName`,`OwnedWinery`) VALUES
(7,'Bouchaib','Opus One Winery');



-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `api` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `retailer` (
	`RetailerName` varchar(50) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `Retailer` (`RetailerName`) VALUES
('BigGreenGrapeMachine'),
('NoWayRose'),
('TheWayItGoes'),
('WhoLetTheWinesOut'),
('WinesRUs');

CREATE TABLE `sells` (
	`WineryID` INT(11) NOT NULL,
    `WineName` varchar(50) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `Sells` (`WineryID`, `WineTitle`) VALUES
(1, ' Albariño'),
(1, ' Zinfandel'),
(1, 'Carménère Reserva'),
(1, 'Chenin Blanc Reserve'),
(1, 'Domaine de la Rivière'),
(1, 'Merlot Gran Reserva'),
(1, 'Pinot Noir Réserve'),
(1, 'Syrah Reserva'),
(1, 'Zinfandel Old Vine'),
(2, 'Barolo Classico'),
(2, 'Cabernet Frac'),
(2, 'Chardonnay Reserve'),
(2, 'Chenin Blanc Sec'),
(2, 'Clos de la Vallée'),
(2, 'Gewürztraminer Vendanges Tardives'),
(2, 'Viognier'),
(3, 'Bodegas del Sol'),
(3, 'Château Montagne'),
(3, 'Chenin Blanc Sec'),
(3, 'Chianti Classico'),
(3, 'Gewürztraminer Vendanges Tardives'),
(3, 'Pinot Grigio di Mare'),
(3, 'Riesling Kabinett'),
(3, 'Syrah'),
(3, 'Villa Rosa'),
(4, 'Cabernet Sauvignon Gran Reserva'),
(4, 'Castillo de Oro'),
(4, 'Château Belle Vue'),
(4, 'Chianti Classico'),
(4, 'Malbec Reserva'),
(4, 'Merlot Reserve'),
(4, 'Pinot Gris'),
(4, 'Sangiovese Riserva'),
(4, 'Syrah Reserva'),
(4, 'Viognier Reserve'),
(5, 'Cabernet Sauvignon'),
(5, 'Chardonnay'),
(5, 'Chateau La Vigne'),
(5, 'Chianti Classico Riserva'),
(5, 'Malbec Reserve'),
(5, 'Montepulciano Reserva'),
(5, 'Pinot Noir'),
(5, 'Rioja Reserva'),
(5, 'Sauvignon Blanc Reserva'),
(5, 'Tempranillo Reserva'),
(6, ' Sauvignon Blanc'),
(6, 'Amarone della Valpolicella'),
(6, 'Chardonnay Grand Cru'),
(6, 'Chenin Blanc'),
(6, 'Gewürztraminer'),
(6, 'Riesling Spätlese'),
(6, 'Sangiovese'),
(7, 'Cabernet Franc'),
(7, 'Chardonnay Reserve'),
(7, 'Domaine de la Rivière');

CREATE TABLE `species` (
	`WineryID` INT(11) NOT NULL,
    `FarmName` VARCHAR(50) NOT NULL,
    `SpeciesName` VARCHAR(50) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `Species` (`FarmName`, `WineryID`, `SpeciesName`) VALUES
( 1, 'The Big bad Grape','Sangiovese'),
(2, 'Rose Tinted', 'Green Grapes'),
( 3,'Winds of Napa Valley', 'Cabernet'),
(3,'The Big bad Grape',  'Red Grapes'),
( 7,'The Green Vinyard', 'Chardonney');

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `password`, `api`, `salt`) VALUES
(7, 'Bouchaib', 'Chraf', 'bmchraf@gmail.com', 'c1b6fda4ec8513a2e4dc784cc1aedaa31d5e142d902bfbaad21b17e36bc2c444', 'cb6e7573a1', '3e6270852c'),
(8, 'Nada', 'Chraf', 'chrafnadax@gmail.com', '56a0b312b8ee90fe2b59b96e2521792aabe0c884d38c400aa52b6922608abe3f', '6a981de338', 'f35d67620e'),
(9, 'Aicha', 'Chraf', 'chrafaicha@gmail.com', '92ec5ea61d8f676ae09888b82a43b4667a5030d9952cdd901fb6aa32147dff30', '2eb3178540', 'ad9dfd3b6e');

-- --------------------------------------------------------

--
-- Table structure for table `winery`
--

CREATE TABLE `winery` (
  `WineryID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Verified` tinyint(4) DEFAULT 0,
  `Country` varchar(255) DEFAULT NULL,
  `Province` varchar(255) DEFAULT NULL,
  `Town` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `winery`
--

INSERT INTO `winery` (`WineryID`, `Name`, `Verified`, `Country`, `Province`, `Town`, `Image`) VALUES
(1, 'Château Margaux', 0, 'France', 'Bordeaux', 'Margaux', 'chateau_margaux.jpg'),
(2, 'Opus One Winery', 1, 'United States', 'California', 'Oakville', 'opus_one_winery.jpg'),
(3, 'Marqués de Riscal', 1, 'Spain', 'Rioja', 'Elciego', 'marques_de_riscal.jpg'),
(4, 'Domaine de la Romanée-Conti', 1, 'France', 'Burgundy', 'Vosne-Romanée', 'romanee_conti.jpg'),
(5, 'Penfolds', 0, 'Australia', 'South Australia', 'Magill', 'penfolds.jpg'),
(6, 'Antinori', 1, 'Italy', 'Tuscany', 'Florence', 'antinori.jpg'),
(7, 'Quintessa Winery', 0, 'United States', 'California', 'Rutherford', 'quintessa_winery.jpg'),
(8, 'Torres', 1, 'Spain', 'Catalonia', 'Vilafranca del Penedès', 'torres.jpg'),
(9, 'Cloudy Bay', 1, 'New Zealand', 'Marlborough', 'Blenheim', 'cloudy_bay.jpg'),
(10, 'Caymus Vineyards', 1, 'United States', 'California', 'Rutherford', 'caymus_vineyards.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wines`
--

CREATE TABLE `wines` (
  `WineID` int(11) NOT NULL,
  `WineryID` int(11) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Type` varchar(255) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `Price` decimal(8,2) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Region` varchar(255) DEFAULT NULL,
  `Acidity` decimal(4,2) DEFAULT NULL,
  `AlcoholContent` decimal(4,2) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Season` varchar(255) DEFAULT NULL,
  `Grape` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wines`
--

INSERT INTO `wines` (`WineID`, `WineryID`, `Name`, `Type`, `Rating`, `Price`, `Year`, `Region`, `Acidity`, `AlcoholContent`, `Description`, `Season`, `Grape`, `Image`) VALUES
(1, 1, 'Château Margaux Red', 'Red', 5, '500.00', 2015, 'Bordeaux', '3.50', '13.50', 'A classic Bordeaux red wine with rich flavors.', 'Winter', 'Cabernet Sauvignon', 'chateau_margaux_red.jpg'),
(2, 1, 'Château Margaux White', 'White', 5, '350.00', 2019, 'Bordeaux', '3.20', '12.00', 'An elegant white wine with citrus notes.', 'Spring', 'Sauvignon Blanc', 'chateau_margaux_white.jpg'),
(3, 2, 'Opus One Red', 'Red', 5, '600.00', 2016, 'Napa Valley', '3.80', '14.00', 'A bold and complex red blend.', 'Winter', 'Cabernet Sauvignon, Merlot', 'opus_one_red.jpg'),
(4, 2, 'Opus One Rosé', 'Rosé', 4, '200.00', 2020, 'Napa Valley', '3.00', '13.50', 'A refreshing rosé wine with floral aromas.', 'Summer', 'Syrah, Cabernet Sauvignon', 'opus_one_rose.jpg'),
(5, 3, 'Marqués de Riscal Reserva', 'Red', 5, '40.00', 2015, 'Rioja', '3.20', '13.00', 'A smooth and balanced red wine from Rioja.', 'Autumn', 'Tempranillo', 'marques_de_riscal_reserva.jpg'),
(6, 3, 'Marqués de Riscal Rosado', 'Rosé', 4, '25.00', 2021, 'Rioja', '3.10', '12.50', 'A delightful rosé wine with hints of red berries.', 'Summer', 'Grenache, Tempranillo', 'marques_de_riscal_rosado.jpg'),
(7, 4, 'Romanée-Conti Grand Cru', 'Red', 5, '1500.00', 2018, 'Burgundy', '3.30', '13.50', 'An exceptional red wine from Burgundy.', 'Winter', 'Pinot Noir', 'romanee_conti_grand_cru.jpg'),
(8, 4, 'Romanée-Conti Montrachet', 'White', 5, '1200.00', 2017, 'Burgundy', '3.40', '12.50', 'A prestigious white wine with finesse and complexity.', 'Spring', 'Chardonnay', 'romanee_conti_montrachet.jpg'),
(9, 5, 'Penfolds Grange', 'Red', 5, '800.00', 2016, 'South Australia', '3.70', '14.50', 'A flagship red wine with intense flavors and long aging potential.', 'Autumn', 'Shiraz', 'penfolds_grange.jpg'),
(10, 5, 'Penfolds Yattarna Chardonnay', 'White', 5, '100.00', 2019, 'South Australia', '3.20', '13.00', 'An elegant and well-structured Chardonnay with a vibrant palate.', 'Summer', 'Chardonnay', 'penfolds_yattarna_chardonnay.jpg'),
(11, 6, 'Antinori Tignanello', 'Red', 5, '150.00', 2017, 'Tuscany', '3.60', '13.50', 'A Tuscan red blend with rich fruit flavors and velvety tannins.', 'Autumn', 'Sangiovese, Cabernet Sauvignon', 'antinori_tignanello.jpg'),
(12, 6, 'Antinori Cervaro della Sala', 'White', 5, '70.00', 2019, 'Umbria', '3.30', '13.00', 'An elegant white wine with floral aromas and a creamy texture.', 'Spring', 'Chardonnay, Grechetto', 'antinori_cervaro_della_sala.jpg'),
(13, 7, 'Quintessa Red', 'Red', 5, '200.00', 2016, 'Napa Valley', '3.70', '14.50', 'A Bordeaux-style red blend with great depth and structure.', 'Winter', 'Cabernet Sauvignon, Merlot, Cabernet Franc', 'quintessa_red.jpg'),
(14, 7, 'Quintessa Illumination', 'White', 4, '80.00', 2020, 'Napa Valley', '3.10', '13.00', 'A vibrant white wine with bright fruit flavors and a lively finish.', 'Summer', 'Sauvignon Blanc, Semillon', 'quintessa_illumination.jpg'),
(15, 8, 'Torres Mas La Plana', 'Red', 5, '90.00', 2016, 'Penedès', '3.50', '14.00', 'A full-bodied red wine with ripe fruit and spicy undertones.', 'Autumn', 'Cabernet Sauvignon', 'torres_mas_la_plana.jpg'),
(16, 8, 'Torres Viña Sol', 'White', 4, '15.00', 2020, 'Penedès', '3.20', '12.50', 'A refreshing and easy-drinking white wine with crisp citrus flavors.', 'Summer', 'Parrellada', 'torres_vina_sol.jpg'),
(17, 9, 'Cloudy Bay Sauvignon Blanc', 'White', 5, '35.00', 2021, 'Marlborough', '3.10', '13.00', 'An iconic New Zealand Sauvignon Blanc with vibrant tropical fruit notes.', 'Spring', 'Sauvignon Blanc', 'cloudy_bay_sauvignon_blanc.jpg'),
(18, 9, 'Cloudy Bay Pinot Noir', 'Red', 5, '40.00', 2018, 'Marlborough', '3.40', '13.50', 'A silky and aromatic Pinot Noir with red fruit flavors.', 'Autumn', 'Pinot Noir', 'cloudy_bay_pinot_noir.jpg'),
(19, 10, 'Caymus Special Selection', 'Red', 5, '300.00', 2017, 'Napa Valley', '3.60', '15.00', 'An opulent and powerful red wine with concentrated dark fruit flavors.', 'Winter', 'Cabernet Sauvignon', 'caymus_special_selection.jpg'),
(20, 10, 'Caymus Conundrum', 'White', 4, '25.00', 2020, 'California', '3.30', '13.50', 'A unique white blend with layers of tropical fruit and floral notes.', 'Summer', 'Chardonnay, Sauvignon Blanc, Muscat', 'caymus_conundrum.jpg'),
(21, 1, 'Château Margaux Médoc', 'Red', 5, '400.00', 2014, 'Bordeaux', '3.40', '13.00', 'A refined red wine with velvety tannins and a long finish.', 'Autumn', 'Cabernet Sauvignon, Merlot', 'chateau_margaux_medoc.jpg'),
(22, 1, 'Château Margaux Blanc', 'White', 5, '300.00', 2018, 'Bordeaux', '3.30', '12.50', 'A complex white wine with layers of citrus and mineral notes.', 'Spring', 'Sauvignon Blanc, Semillon', 'chateau_margaux_blanc.jpg'),
(23, 2, 'Opus One Overture', 'Red', 5, '150.00', 2015, 'Napa Valley', '3.50', '14.50', 'A harmonious red blend with a smooth and supple texture.', 'Winter', 'Cabernet Sauvignon, Merlot, Cabernet Franc', 'opus_one_overture.jpg'),
(24, 2, 'Opus One Sauvignon Blanc', 'White', 4, '80.00', 2021, 'Napa Valley', '3.20', '13.00', 'A vibrant and aromatic Sauvignon Blanc with lively acidity.', 'Summer', 'Sauvignon Blanc', 'opus_one_sauvignon_blanc.jpg'),
(25, 3, 'Marqués de Riscal Gran Reserva', 'Red', 5, '60.00', 2014, 'Rioja', '3.30', '13.50', 'A complex and elegant red wine with layers of dark fruit and spice.', 'Winter', 'Tempranillo, Graciano, Mazuelo', 'marques_de_riscal_gran_reserva.jpg'),
(26, 3, 'Marqués de Riscal Limousin', 'White', 4, '35.00', 2019, 'Rueda', '3.20', '12.50', 'A crisp and aromatic white wine with floral and citrus notes.', 'Spring', 'Verdejo', 'marques_de_riscal_limousin.jpg'),
(27, 4, 'Romanée-Conti La Tâche', 'Red', 5, '1800.00', 2016, 'Burgundy', '3.50', '13.50', 'A legendary red wine with exceptional finesse and complexity.', 'Winter', 'Pinot Noir', 'romanee_conti_la_tache.jpg'),
(28, 4, 'Romanée-Conti Corton', 'White', 5, '1300.00', 2015, 'Burgundy', '3.40', '12.50', 'A rare and exquisite white wine with remarkable depth and elegance.', 'Spring', 'Chardonnay', 'romanee_conti_corton.jpg'),
(29, 5, 'Penfolds Bin 389', 'Red', 5, '80.00', 2017, 'South Australia', '3.70', '14.50', 'A classic Australian red blend with rich dark fruit and toasty oak.', 'Autumn', 'Cabernet Sauvignon, Shiraz', 'penfolds_bin_389.jpg'),
(30, 5, 'Penfolds Riesling', 'White', 4, '30.00', 2020, 'Eden Valley', '3.20', '12.00', 'A vibrant and aromatic Riesling with zesty citrus flavors.', 'Summer', 'Riesling', 'penfolds_riesling.jpg'),
(31, 6, 'Antinori Guado al Tasso', 'Red', 5, '120.00', 2017, 'Tuscany', '3.60', '14.00', 'A powerful and complex Super Tuscan with velvety tannins and a long finish.', 'Autumn', 'Cabernet Sauvignon, Merlot, Cabernet Franc', 'antinori_guado_al_tasso.jpg'),
(32, 6, 'Antinori Bramìto Chardonnay', 'White', 5, '40.00', 2019, 'Tuscany', '3.30', '13.00', 'A crisp and elegant Chardonnay with notes of apple and tropical fruit.', 'Spring', 'Chardonnay', 'antinori_bramito_chardonnay.jpg'),
(33, 7, 'Quintessa Cabernet Sauvignon', 'Red', 5, '250.00', 2015, 'Napa Valley', '3.80', '14.50', 'An opulent and age-worthy Cabernet Sauvignon with layers of black fruit and spices.', 'Winter', 'Cabernet Sauvignon', 'quintessa_cabernet_sauvignon.jpg'),
(34, 7, 'Quintessa Illuminati', 'White', 4, '80.00', 2021, 'Napa Valley', '3.20', '13.00', 'A vibrant and aromatic white wine with layers of citrus and floral notes.', 'Summer', 'Sauvignon Blanc, Chardonnay, Viognier', 'quintessa_illuminati.jpg'),
(35, 8, 'Torres Mas La Plana Cabernet Sauvignon', 'Red', 5, '100.00', 2017, 'Penedès', '3.50', '14.00', 'A full-bodied and elegant Cabernet Sauvignon with ripe black fruit flavors.', 'Autumn', 'Cabernet Sauvignon', 'torres_mas_la_plana_cabernet_sauvignon.jpg'),
(36, 8, 'Torres Fransola Sauvignon Blanc', 'White', 4, '30.00', 2020, 'Penedès', '3.30', '13.00', 'A crisp and aromatic Sauvignon Blanc with tropical fruit and herbal notes.', 'Spring', 'Sauvignon Blanc', 'torres_fransola_sauvignon_blanc.jpg'),
(37, 9, 'Cloudy Bay Te Koko Sauvignon Blanc', 'White', 5, '55.00', 2018, 'Marlborough', '3.30', '13.50', 'A complex and textured Sauvignon Blanc with flavors of tropical fruit and nutty undertones.', 'Summer', 'Sauvignon Blanc', 'cloudy_bay_te_koko_sauvignon_blanc.jpg'),
(38, 9, 'Cloudy Bay Pinot Gris', 'White', 4, '35.00', 2021, 'Marlborough', '3.10', '13.00', 'A medium-bodied white wine with stone fruit flavors and a crisp finish.', 'Spring', 'Pinot Gris', 'cloudy_bay_pinot_gris.jpg'),
(39, 10, 'Caymus Napa Valley Cabernet Sauvignon', 'Red', 5, '90.00', 2018, 'Napa Valley', '3.60', '14.50', 'A rich and velvety Cabernet Sauvignon with layers of dark fruit and mocha.', 'Autumn', 'Cabernet Sauvignon', 'caymus_napa_valley_cabernet_sauvignon.jpg'),
(40, 10, 'Caymus Mer Soleil Chardonnay', 'White', 4, '40.00', 2020, 'Santa Lucia Highlands', '3.30', '13.50', 'A creamy and full-bodied Chardonnay with tropical fruit flavors.', 'Summer', 'Chardonnay', 'caymus_mer_soleil_chardonnay.jpg'),
(41, 1, 'Château Margaux Pavillon Rouge', 'Red', 5, '300.00', 2013, 'Bordeaux', '3.40', '13.00', 'A refined and elegant red wine with fine-grained tannins and a long finish.', 'Winter', 'Cabernet Sauvignon, Merlot', 'chateau_margaux_pavillon_rouge.jpg'),
(42, 1, 'Château Margaux Pavillon Blanc', 'White', 5, '250.00', 2017, 'Bordeaux', '3.30', '12.50', 'A complex and expressive white wine with floral and citrus aromas.', 'Spring', 'Sauvignon Blanc, Semillon', 'chateau_margaux_pavillon_blanc.jpg'),
(43, 2, 'Opus One Merlot', 'Red', 5, '250.00', 2014, 'Napa Valley', '3.50', '14.00', 'A velvety and luscious Merlot with layers of black cherry and chocolate.', 'Autumn', 'Merlot', 'opus_one_merlot.jpg'),
(44, 2, 'Opus One Chardonnay', 'White', 4, '120.00', 2019, 'Napa Valley', '3.20', '13.00', 'A rich and creamy Chardonnay with flavors of ripe apple and toasted oak.', 'Summer', 'Chardonnay', 'opus_one_chardonnay.jpg'),
(45, 3, 'Marqués de Riscal Barón de Chirel', 'Red', 5, '80.00', 2013, 'Rioja', '3.40', '13.50', 'A powerful and concentrated red wine with intense fruit and spicy notes.', 'Winter', 'Tempranillo, Cabernet Sauvignon, Graciano', 'marques_de_riscal_baron_de_chirel.jpg'),
(46, 3, 'Marqués de Riscal Limousin Reserva', 'White', 4, '40.00', 2018, 'Rueda', '3.20', '12.50', 'A crisp and aromatic white wine with floral and citrus flavors.', 'Spring', 'Verdejo', 'marques_de_riscal_limousin_reserva.jpg'),
(47, 4, 'Romanée-Conti Échézeaux', 'Red', 5, '1500.00', 2014, 'Burgundy', '3.50', '13.50', 'A highly sought-after red wine with great structure and finesse.', 'Winter', 'Pinot Noir', 'romanee_conti_echezeaux.jpg'),
(48, 4, 'Romanée-Conti Montrachet Grand Cru', 'White', 5, '1300.00', 2013, 'Burgundy', '3.40', '12.50', 'A prestigious white wine with exquisite balance and complexity.', 'Spring', 'Chardonnay', 'romanee_conti_montrachet_grand_cru.jpg'),
(49, 5, 'Penfolds St. Henri Shiraz', 'Red', 5, '150.00', 2015, 'South Australia', '3.70', '14.50', 'A refined and elegant Shiraz with fine-grained tannins and a long finish.', 'Autumn', 'Shiraz', 'penfolds_st_henri_shiraz.jpg'),
(50, 5, 'Penfolds Yattarna Bin 144 Chardonnay', 'White', 5, '80.00', 2018, 'South Australia', '3.30', '13.00', 'A complex and layered Chardonnay with vibrant acidity and a creamy texture.', 'Summer', 'Chardonnay', 'penfolds_yattarna_bin_144_chardonnay.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`WineID`,`UserID`),
  ADD KEY `UserID` (`UserID`);

ALTER TABLE `customer`
	ADD PRIMARY KEY(`UserID`);
    
ALTER TABLE `expert`
	ADD PRIMARY KEY(`UserID`);
    
ALTER TABLE `farm`
	ADD PRIMARY KEY(`FarmName`);
--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

ALTER TABLE `favouriteWines`
	ADD PRIMARY KEY(`UserID`, `WineID`),
    ADD KEY `UserID` (`UserID`);
--
-- Indexes for table `winery`
--
ALTER TABLE `winery`
  ADD PRIMARY KEY (`WineryID`);
  
  ALTER TABLE `manager`
	ADD PRIMARY KEY(`UserID`);

ALTER TABLE `retailer`
	ADD PRIMARY KEY(`RetailerName`);

-- Indexes for table `wines`
--
ALTER TABLE `wines`
  ADD PRIMARY KEY (`WineID`),
  ADD KEY `WineryID` (`WineryID`);

ALTER TABLE `has`
	ADD PRIMARY KEY(`WindID`);
    
ALTER TABLE `sells`
	ADD PRIMARY KEY(`WineryID`);
    
ALTER TABLE `species`
	ADD PRIMARY KEY(`WineryID`);
--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

ALTER TABLE `accounts`
  MODIFY `AccountID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `winery`
--
ALTER TABLE `winery`
  MODIFY `WineryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

-- AUTO_INCREMENT for table `wines`
--
ALTER TABLE `wines`
  MODIFY `WineID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`WineID`) REFERENCES `wines` (`WineID`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `users` (`id`);
  
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`id`);

ALTER TABLE `customers`
ADD CONSTRAINT `fk_UserID` FOREIGN KEY (`UserID`) REFERENCES `users` (`id`);

ALTER TABLE `has`
	ADD CONSTRAINT `has_ibfk_1` FOREIGN KEY (`WineID`) REFERENCES `wines` (`WineID`);
--
ALTER TABLE `favouriteWines`
  ADD CONSTRAINT `favouriteWines_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `favouriteWines_ibfk_2` FOREIGN KEY (`WineID`) REFERENCES `wines` (`WineID`);

ALTER TABLE `expert`
ADD CONSTRAINT `fk_UserID1` FOREIGN KEY (`UserID`) REFERENCES `users` (`id`);

ALTER TABLE `sells`
ADD CONSTRAINT `sells_ibfk_1` FOREIGN KEY (`WineryID`) REFERENCES `winery` (`WineryID`);

ALTER TABLE `species`
ADD CONSTRAINT `sells_ibfk_1` FOREIGN KEY (`WineryID`) REFERENCES `winery` (`WineryID`);

-- Constraints for table `wines`
--
ALTER TABLE `wines`
  ADD CONSTRAINT `wines_ibfk_1` FOREIGN KEY (`WineryID`) REFERENCES `winery` (`WineryID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
