MainSQL is the main sql database consisting of all the main data and connections.

Where as User_Local is the sql database we had connected to the web application through a phpmyadmin server.