In this folder there is a collection of EER diagram and Relational Mapping Iterations.
This shows how our idea chnaged as we were moving through the project perfecting it.