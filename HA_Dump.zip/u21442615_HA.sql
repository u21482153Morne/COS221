-- phpMyAdmin SQL Dump
-- version 5.0.4deb2~bpo10+1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 31, 2023 at 08:06 AM
-- Server version: 10.3.31-MariaDB-0+deb10u1
-- PHP Version: 7.3.31-1~deb10u3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u21442615_HA`
--

-- --------------------------------------------------------

--
-- Table structure for table `Accounts`
--

CREATE TABLE `Accounts` (
  `AccountID` int(10) UNSIGNED NOT NULL,
  `Verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Accounts`
--

INSERT INTO `Accounts` (`AccountID`, `Verified`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `CustomerName` varchar(50) NOT NULL,
  `PrefferedWineType` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` (`UserID`, `CustomerName`, `PrefferedWineType`) VALUES
(1, 'Bryce Sukhdeo', 'Merlot'),
(2, 'Clive Bixley', 'Chardonney');

-- --------------------------------------------------------

--
-- Table structure for table `Expert`
--

CREATE TABLE `Expert` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `ExpertName` varchar(50) NOT NULL,
  `Certification` text DEFAULT NULL,
  `Organisation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Expert`
--

INSERT INTO `Expert` (`UserID`, `ExpertName`, `Certification`, `Organisation`) VALUES
(3, 'William Wine III', 'Connoisseur', 'WeLoveWineSA');

-- --------------------------------------------------------

--
-- Table structure for table `Farm`
--

CREATE TABLE `Farm` (
  `FarmName` varchar(50) NOT NULL,
  `Country` text DEFAULT NULL,
  `Province` text DEFAULT NULL,
  `Images` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Farm`
--

INSERT INTO `Farm` (`FarmName`, `Country`, `Province`, `Images`) VALUES
('Greensborough Estates', 'England', 'Birmingham', ''),
('The Big bad Grape', 'South Africa', 'Limpopo', ''),
('The Green Vinyard', 'Portugal', 'Porto', '');

-- --------------------------------------------------------

--
-- Table structure for table `FavoriteWines`
--

CREATE TABLE `FavoriteWines` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `WineTitle` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `FavoriteWines`
--

INSERT INTO `FavoriteWines` (`UserID`, `WineTitle`) VALUES
(1, 'Zinfandel'),
(2, 'Riesling Spätlese'),
(3, 'Château Belle Vue'),
(4, 'Malbec Reserva');

-- --------------------------------------------------------

--
-- Table structure for table `Has`
--

CREATE TABLE `Has` (
  `RetailerName` varchar(50) NOT NULL,
  `WineTitle` varchar(50) NOT NULL,
  `Units` int(200) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Has`
--

INSERT INTO `Has` (`RetailerName`, `WineTitle`, `Units`) VALUES
('WhoLetTheWinesOut', 'Malbec Reserva', 55),
('WinesRUs', 'Zinfandel', 300);

-- --------------------------------------------------------

--
-- Table structure for table `Imports`
--

CREATE TABLE `Imports` (
  `FarmName` varchar(50) NOT NULL,
  `WineryID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Imports`
--

INSERT INTO `Imports` (`FarmName`, `WineryID`) VALUES
('The Big bad Grape', 3),
('The Green Vinyard', 7);

-- --------------------------------------------------------

--
-- Table structure for table `Manager`
--

CREATE TABLE `Manager` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `ManagerName` varchar(50) NOT NULL,
  `OwnedWinery` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Manager`
--

INSERT INTO `Manager` (`UserID`, `ManagerName`, `OwnedWinery`) VALUES
(4, 'Theo Von', 'Delaire Graff Estate'),
(5, 'Kevin De Bruyne', 'Holden Manz Wine Estate');

-- --------------------------------------------------------

--
-- Table structure for table `Retailer`
--

CREATE TABLE `Retailer` (
  `RetailerName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Retailer`
--

INSERT INTO `Retailer` (`RetailerName`) VALUES
('BigGreenGrapeMachine'),
('NoWayRose'),
('TheWayItGoes'),
('WhoLetTheWinesOut'),
('WinesRUs');

-- --------------------------------------------------------

--
-- Table structure for table `Reviews`
--

CREATE TABLE `Reviews` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `WinesTitle` varchar(50) NOT NULL,
  `Rating` float UNSIGNED DEFAULT NULL,
  `TimeOfReview` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Reviews`
--

INSERT INTO `Reviews` (`UserID`, `WinesTitle`, `Rating`, `TimeOfReview`) VALUES
(1, 'Chardonnay', 4.5, '2023-05-28 16:13:48'),
(1, 'Château Belle Vue', 3.6, '2023-05-28 16:13:48'),
(2, 'Chianti Classico Riserva', 3, '2023-05-28 16:13:48'),
(3, 'Chateau La Vigne', 4.2, '2023-05-28 16:13:48');

-- --------------------------------------------------------

--
-- Table structure for table `Sells`
--

CREATE TABLE `Sells` (
  `WineryID` int(10) UNSIGNED NOT NULL,
  `WineTitle` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Sells`
--

INSERT INTO `Sells` (`WineryID`, `WineTitle`) VALUES
(1, 'Domaine de la Rivière'),
(2, 'Gewürztraminer Vendanges Tardives'),
(3, 'Chenin Blanc Sec'),
(4, 'Chianti Classico'),
(4, 'Syrah Reserva'),
(7, 'Chardonnay Reserve');

-- --------------------------------------------------------

--
-- Table structure for table `Species`
--

CREATE TABLE `Species` (
  `FarmName` varchar(50) NOT NULL,
  `WineryID` int(10) UNSIGNED NOT NULL,
  `SpeciesName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Species`
--

INSERT INTO `Species` (`FarmName`, `WineryID`, `SpeciesName`) VALUES
('The Big bad Grape', 3, 'Red Grapes'),
('The Green Vinyard', 7, 'Chardonney');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `UserID` int(10) UNSIGNED NOT NULL,
  `AccID` int(10) UNSIGNED NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `API_Key` varchar(200) NOT NULL,
  `Age` int(3) UNSIGNED DEFAULT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`UserID`, `AccID`, `Email`, `API_Key`, `Age`, `Username`, `Password`) VALUES
(1, 1, 'bryce.sukhdeo@gmail.com', 'sdbaouibwei2g9ubjsdkansdwn', 20, 'Bryce_axl', '1234'),
(2, 2, 'this.hello@hotmail.com', 'dshudbuiqwbibcasjndn', 65, 'old_guy_123', '12345'),
(3, 3, 'wine.enthusiast@gmail.com', 'hsdiuhgiqubhjsdbjkw', 30, 'I_Love_Wine', 'WineLover123'),
(4, 4, 'wheresThewine@yahoo.com', 'dschbdcn2moesm2o', 41, 'Chardonney_fiend', '80909'),
(5, 5, 'coolguy24@gmail.com', 'bsqiwbwiehce3', 19, 'MerlotMarauder12', '909090');

-- --------------------------------------------------------

--
-- Table structure for table `Winery`
--

CREATE TABLE `Winery` (
  `WineryID` int(10) UNSIGNED NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Verified` tinyint(1) NOT NULL,
  `Country` text DEFAULT NULL,
  `Province` text DEFAULT NULL,
  `Town` text NOT NULL,
  `Images` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Winery`
--

INSERT INTO `Winery` (`WineryID`, `Name`, `Verified`, `Country`, `Province`, `Town`, `Images`) VALUES
(1, 'Antinori nel Chianti Classico', 1, 'Italy', 'Tuscany', 'Tuscany', ''),
(2, 'Montes', 1, 'Chile', 'Colchagua', 'San Fernando', ''),
(3, 'Schloss Johannisberg', 1, 'Germany', 'Rheingau', 'Wiesbaden', ''),
(4, 'Quinta do Crasto', 1, 'Portugal', 'Douro Valley', 'Castile', ''),
(5, 'Bodegas de los Herederos del Marqués de Riscal', 1, 'Spain', 'Rioja', 'Álava', ''),
(6, 'Delaire Graff Estate', 1, 'South Africa', 'Western Cape ', 'Stellenbosch', ''),
(7, 'Holden Manz Wine Estate', 1, 'South Africa', 'Western Cape', 'Paarl', '');

-- --------------------------------------------------------

--
-- Table structure for table `Wines`
--

CREATE TABLE `Wines` (
  `Title` varchar(50) NOT NULL,
  `WineryID` int(10) UNSIGNED NOT NULL,
  `WineID` int(10) UNSIGNED NOT NULL,
  `Category` text NOT NULL,
  `Points` int(3) UNSIGNED DEFAULT NULL,
  `Price` float UNSIGNED DEFAULT NULL,
  `Vintage` int(4) UNSIGNED DEFAULT NULL,
  `Region` text DEFAULT NULL,
  `Acidity` float UNSIGNED DEFAULT NULL,
  `AlcholContent` float UNSIGNED DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Season` text DEFAULT NULL,
  `Grape` text DEFAULT NULL,
  `Images` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Wines`
--

INSERT INTO `Wines` (`Title`, `WineryID`, `WineID`, `Category`, `Points`, `Price`, `Vintage`, `Region`, `Acidity`, `AlcholContent`, `Description`, `Season`, `Grape`, `Images`) VALUES
(' Albariño', 6, 48, '', 88, 35.6, 2012, 'Rías Baixas', 6.3, 13.5, 'A crisp and aromatic white wine with flavors of citrus, peach, and a mineral edge.', 'Autumn', 'Albariño', 'https://springfieldestate.com/wp-content/uploads/2019/11/Albarino-pack-NV.png'),
(' Sauvignon Blanc', 7, 3, '', 67, 28.9, 2018, 'Marlbourogh', 5.2, 12.8, ' A crisp and refreshing Sauvignon Blanc with vibrant citrus flavors.', 'Spring', 'Sauvignon blanc ', 'https://images.wine.co.za/GetWineImage.ashx?ImageSize=large&IMAGEID=269261'),
(' Zinfandel', 6, 10, '', 70, 34.2, 2012, 'California', 4.2, 14.8, 'A rich and jammy Zinfandel with blackberry and vanilla notes.', 'Summer', 'Zinfandel', 'https://idiom.co.za/wp-content/uploads/2020/08/Idiom-Collection-Zinfandel-2016.jpg'),
('Amarone della Valpolicella', 3, 36, '', 77, 47.8, 2012, 'Veneto', 6.6, 15.5, 'A full-bodied red wine with rich flavors of dried fruits, chocolate, and spice.', 'Winter', 'Corvina', 'https://www.tommasi.com/wp-content/uploads/2020/10/AMARONE_CLASSICO.png'),
('Barolo Classico', 5, 26, '', 85, 37.6, 2013, 'Piedmont', 6.8, 14.5, 'A bold and structured red wine with intense tannins and notes of cherry and truffle.', 'Winter', 'Nebbiolo', 'https://produits.bienmanger.com/38036-0w600h600_Boroli_Barolo_Classico_Italian_Red_Wine.jpg'),
('Bodegas del Sol', 7, 21, '', 89, 29.3, 2007, 'Loire Valley', 3.9, 13.5, 'A complex red wine with layers of blackberry, tobacco, and vanilla.', 'Winter', 'Tempranillo', 'https://trescumbres.wine/wp-content/uploads/2021/06/mv-la-bodega-delsol.jpg'),
('Cabernet Frac', 1, 11, '', 63, 37.9, 2006, 'Loire Valley', 4.1, 13.9, 'A medium-bodied Cabernet Franc with red fruit flavors and herbal hints.', 'Autumn', 'Cabernet Franc', 'https://www.vnl.co.za/wp-content/uploads/2017/06/VL-Cab-Franc-NV.png'),
('Cabernet Franc', 4, 40, '', 75, 27.8, 2016, 'Finger Lakes', 6.7, 13.8, 'A medium-bodied red wine with flavors of raspberry, bell pepper, and a hint of tobacco.', 'Winter', 'Cabernet Franc', 'https://raats.co.za/wp-content/uploads/2017/02/Raats-Family-Cab-Franc-1.jpg'),
('Cabernet Sauvignon', 6, 4, '', 59, 62.75, 1995, 'Napa Valley', 4.6, 15, 'A bold and robust Cabernet Sauvignon with dark fruit and oak undertones.', 'Winter', 'Cabernet Sauvignon', 'https://darlingwine.co.za/wp-content/uploads/2020/05/Dc-Red-blend-Webiste.jpg'),
('Cabernet Sauvignon Gran Reserva', 6, 29, '', 85, 44.5, 2011, 'Maipo Valley', 6, 14.5, 'A full-bodied red wine with bold flavors of blackcurrant, chocolate, and tobacco.', 'Winter', 'Cabernet Sauvignon', 'https://media.liquormax.com/eq4rxnkvcouvc1anfqqhe/cyt-gran-res.png'),
('Carménère Reserva', 5, 47, '', 82, 32.9, 2010, 'Colchagua Valley', 6.5, 14, 'A rich and velvety red wine with blackberry and spicy notes and a long, smooth finish.', 'Winter', 'Carménère', 'https://static1.squarespace.com/static/5eb8e00d7ce1b6082128f13c/5ec2368e80b6627d6b88074e/5eddefe6f510a4510b433d64/1680771660286/Casa+Silva+Reserve+Carmanere.png?format=1500w'),
('Castillo de Oro', 2, 27, '', 60, 17.8, 2022, 'Castilla-La Mancha', 6, 13, 'A smooth and fruity red wine with flavors of red berries and a touch of vanilla.', 'Summer', 'Tempranillo', 'https://www.oleobrigado.com/files/wn_163150626111610.jpg'),
('Chardonnay', 6, 1, '', 72, 32.5, 2005, 'Napa Valley', 4.8, 13.5, 'A well-balanced and smooth Chardonnay with hints of tropical fruit.', 'Summer', 'White', 'https://images.wine.co.za/GetWineImage.ashx?ImageSize=large&IMAGEID=269257'),
('Chardonnay Grand Cru', 4, 37, '', 68, 28.5, 2017, 'Burgendy', 6.8, 13.2, 'A complex and creamy white wine with layers of citrus, vanilla, and toasted oak.', 'Summer', 'Chardonney', 'https://images.vivino.com/thumbs/3Bq_p1owQy6DjXBF1ZZtjA_pb_x600.png'),
('Chardonnay Reserve', 3, 28, '', 70, 18.95, 2008, ' California', 6.3, 13.5, 'A rich and buttery white wine with aromas of tropical fruit and a creamy texture.', 'Summer', 'Chardonnay', 'https://cabriere.co.za/wp-content/uploads/Pinot-Noir-Reserve-NV.png'),
('Château Belle Vue', 6, 24, '', 88, 39.6, 2008, 'Bordeaux', 6.4, 13.8, 'A rich and velvety red wine with layers of blackcurrant, cedar, and spice.', 'Autmn', 'Cabernet Sauvignon', 'https://www.bordeaux-tradition.com/wp-content/uploads/2018/03/belle-vue.png'),
('Chateau La Vigne', 3, 17, '', 75, 28.5, 2010, 'Bordeaux', 5.8, 12.7, 'A medium-bodied red wine with a hint of oak and a smooth finish.', 'Summer', 'Merlot', 'https://cdn.shopify.com/s/files/1/0107/7082/products/image_c3111c77-d4d6-4205-8043-8abf94b78b15.jpg?v=1623148100'),
('Château Montagne', 1, 32, '', 65, 14.6, 2023, 'Rhone Valley', 6.2, 12.4, 'A light and fruity rosé wine with flavors of strawberries and a refreshing finish.', 'Summer', 'Grenache', 'https://www.saq.com/media/catalog/product/8/6/864249-1_1580606117.png?quality=80&fit=bounds&height=&width='),
('Chenin Blanc', 5, 16, '', 62, 31.75, 2001, 'Loire Valley', 5.3, 12.5, 'A versatile and crisp Chenin Blanc with notes of green apple and honeydew.', 'Spring', 'Sangiovese', 'https://images.wine.co.za/GetWineImage.ashx?ImageSize=large&IMAGEID=269265'),
('Chenin Blanc Reserve', 3, 50, '', 68, 23.7, 2017, 'Stellenbosch', 6.7, 13.2, ' A crisp and vibrant white wine with flavors of green apple, citrus, and a hint of honey.', 'Spring', 'Chenin Blanc', 'https://kumalawines.co.za/wp-content/uploads/2021/12/Kumala-Reserve-Chenin-Blanc-2019.jpg'),
('Chenin Blanc Sec', 2, 39, '', 62, 19.5, 2022, 'Loire Valley', 6.2, 12.7, 'A dry and crisp white wine with aromas of green apple and a touch of honey.', 'Spring', 'Chenin Blanc', 'https://www.caros.co.nz/media/catalog/product/cache/82c9bf4a0e85458d3f72a5ed32da1346/a/s/astro-chenin-sec-web_1.jpg'),
('Chianti Classico', 4, 15, '', 71, 35.9, 2014, 'Tuscany', 4.6, 13.8, ' A traditional Chianti Classico with bright cherry flavors and a hint of spice.', 'Summer', 'Sangiovese', 'https://www.vinotria.co.za/wp-content/uploads/2019/06/Mon-projet-32.png'),
('Chianti Classico Riserva', 5, 34, '', 82, 34.2, 2010, 'Tuscany', 6.8, 13.5, 'A well-structured red wine with flavors of ripe plum, dried herbs, and a touch of oak.', 'Winter', 'Sangiovese', 'https://cafaggio.wine/wp-content/uploads/2016/04/chianti_classico_riserva.png'),
('Clos de la Vallée', 2, 19, '', 58, 47.9, 2022, 'Abruzzo', 4.8, 10.1, 'An elegant white wine with a floral aroma and a hint of mineral undertones.', 'Summer', 'Sauvignon Blanc', 'https://cdn11.bigcommerce.com/s-a04d0/images/stencil/1280x1280/products/22699/24587/clos-de-los-siete-valle-de-uce-red-wine__63083.1667527458.jpg?c=2'),
('Domaine de la Rivière', 1, 22, '', 67, 34.35, 1998, 'Languedoc-Roussillon', 6.3, 12.2, 'A light-bodied rosé wine with refreshing flavors of strawberries and melon.', 'Spring', 'Grenache', 'https://domaineriviere.com/wp-content/uploads/2020/01/El-Diablo-800x800-2.png'),
('Gewürztraminer', 5, 9, '', 61, 29.75, 1999, 'Alscae', 5.6, 12.3, 'An aromatic and spicy Gewürztraminer with lychee and rose petal flavors.', 'Spring', 'Gewürztraminer', 'https://www.simonsig.co.za/wp-content/uploads/2016/05/Gewurztraminer-2022.png'),
('Gewürztraminer Vendanges Tardives', 4, 46, '', 72, 24.5, 2016, 'Alsace', 6.8, 12.5, 'A luscious and sweet white wine with exotic fruit flavors and a honeyed finish.', 'Spring', 'Gewürztraminer', 'https://medias-prod2205.nicolas.com/media/sys_master/hfe/h72/9433122111518.png'),
('Malbec Reserva', 7, 8, '', 77, 42.9, 2008, 'Mendoza', 3.7, 12.8, ' A bold and velvety Malbec with flavors of black cherries and chocolate.', 'Autmn', 'Malbec', 'https://www.winecellar.co.za/media/catalog/product/cache/faa227d2c35320d740a3e4c001935721/t/e/terrazas-de-los-andes-malbec-reserva-2019-m2.png'),
('Malbec Reserve', 7, 31, '', 90, 36.2, 2009, 'Mendoza', 5.4, 12.5, 'A robust red wine with bold tannins, blackberry notes, and a touch of smokiness.', 'Autumn', 'Malbec', 'https://www.diemersfontein.co.za/wp-content/uploads/2022/09/CD-Malbec.png'),
('Merlot Gran Reserva', 2, 45, '', 58, 18.6, 2021, 'Maipo Valley', 6.3, 12.8, 'A smooth and fruity red wine with flavors of plum, black cherry, and a hint of chocolate.', 'Summer', 'Merlot', 'https://d1av3r99ggsbkh.cloudfront.net/4199-thickbox_default/merlot-gran-reserva-vina-tres-palacios.jpg'),
('Merlot Reserve', 5, 2, '', 81, 76.5, 1999, 'Bordeaux', 3.9, 14.2, 'A rich and velvety Merlot with notes of dark berries and spices.', 'Autumn', 'Red', 'https://vergelegen.co.za/wp-content/uploads/2020/10/Vergelegen-Reserve-Merlot.png'),
('Montepulciano Reserva', 3, 20, '', 67, 21, 2002, 'Rioja', 5.9, 12.4, 'A well-balanced red wine with ripe cherry flavors and a velvety texture.', 'Spring', 'Montepulciano', 'https://www.directwineshipments.com/wp-content/uploads/2017/08/TordelColleMonte.jpg'),
('Pinot Grigio di Mare', 3, 23, '', 70, 20.9, 2017, 'Veneto', 6.6, 12.5, ' A crisp and zesty white wine with a hint of pear and a clean finish.', 'Summer ', 'Pinot Grigio', 'https://images.vivino.com/thumbs/3WkH4xBhSw69ArkCBGA-ew_pb_600x600.png'),
('Pinot Gris', 3, 42, '', 70, 22.9, 2018, 'Alsace', 6.5, 13.5, 'A dry and aromatic white wine with notes of pear, white flowers, and a touch of spice.', 'Spring', 'Pinot Gris', 'https://www.exanimo.co.za/wp-content/uploads/Craven-Pinot-Gris-2022.jpg'),
('Pinot Noir', 7, 5, '', 72, 36, 2010, 'Burgendy', 4.4, 13.7, 'A delicate and elegant Pinot Noir with red fruit and earthy notes.', 'Autumn', 'Pinot Noir', 'https://cdn.shopify.com/s/files/1/0230/5943/1504/products/LL-Culinaria-Pinot-Noir-2021.jpg?v=1672830545'),
('Pinot Noir Réserve', 3, 33, '', 72, 21.5, 2016, 'Burgendy', 6.6, 13, 'A delicate and silky red wine with red cherry flavors and earthy undertones.', 'Spring', 'Pinot noir', 'https://cabriere.co.za/wp-content/uploads/Haute-Cabriere-Pinot-Noir-Reserve.png'),
('Riesling Kabinett', 4, 25, '', 90, 23.5, 2014, 'Mosel', 7.2, 9.5, 'A semi-sweet white wine with vibrant acidity and flavors of peach and honey.', 'Summer', 'Riseling', 'https://www.premiercru.co.za/wp-content/uploads/2022/06/DE-Korrell-Kabinett.png'),
('Riesling Spätlese', 4, 6, '', 56, 24.8, 1985, 'Mosel', 6.1, 9.5, 'A sweet and aromatic Riesling with flavors of ripe peaches and honey', 'Autumn', 'Riesling', 'https://www.greatdomaines.co.za/wp-content/uploads/2023/02/Dr.-Loosen-Riesling-Erdener-Treppchen-SpC3A4tlese-2020-2.jpg'),
('Riesling Spätlese', 7, 35, '', 92, 33.6, 2015, 'Rheingau', 7, 10.5, 'A luscious and sweet white wine with ripe peach flavors and a long, honeyed finish.', 'Spring', 'Riesling', 'https://sf.flatiron-wines.com/cdn/shop/products/Bottle-of-Donnhoff-Niederhauser-Hermannshohle-Riesling-Spatlese-2021-White-Wine-Flatiron-SF.jpg?v=1681779724'),
('Rioja Reserva', 5, 43, '', 85, 34.5, 2013, 'Rioja', 6.7, 13.5, 'A classic red wine with well-integrated oak, red fruit flavors, and a smooth finish.', 'Winter', 'Tempranillo', 'https://reciprocal.co.za/wp-content/uploads/2022/11/7310.png'),
('Sangiovese', 2, 12, '', 67, 30.8, 2015, 'Tuscany ', 4.7, 13.5, 'A classic Sangiovese with cherry and leather aromas and a smooth finish.', 'Winter', 'Sangiovese', 'https://cdn.shopify.com/s/files/1/0708/9425/6437/products/KoelenboschSangiovese2022.png?v=1674474584'),
('Sangiovese Riserva', 1, 49, '', 65, 16.8, 2023, 'Tuscany', 6.2, 12.4, 'A medium-bodied red wine with red cherry flavors, herbal undertones, and a smooth finish.', 'Summer', 'Sangiovese', 'https://umbertocesari.com/wp-content/uploads/2021/05/riserva-scontornato-410-x-1040.png'),
('Sauvignon Blanc Reserva', 4, 30, '', 75, 26.5, 2015, 'Marlbourough', 6.8, 13.2, 'A vibrant and aromatic white wine with zesty citrus flavors and a crisp finish.', 'Summer', 'Sauvignon Blanc', 'https://images.vivino.com/thumbs/cyo8cCjDSgaPKnajvcWGKw_pb_600x600.png'),
('Syrah', 6, 7, '', 65, 51, 2015, 'Rhone Valley', 4.9, 15.5, 'A full-bodied and peppery Syrah with blackberry and smoky notes.', 'Spring', 'Syrah', 'https://www.lomond.co.za/wp-content/uploads/syrah.png'),
('Syrah Reserva', 5, 38, '', 85, 46.5, 2014, 'Colcahgua Valley', 6.4, 15.4, 'A bold and spicy red wine with flavors of black pepper, blackberry, and smoky notes.', 'Autumn', 'Syrah', 'https://www.viorigen.com/wp-content/uploads/2019/03/syrah-reserva.png'),
('Tempranillo Reserva', 6, 14, '', 68, 48.6, 2013, 'Rioja', 4.4, 14, 'A well-structured and mature Tempranillo with flavors of red berries and vanilla.', 'Autumn', 'Tempranillo', 'https://www.greatdomaines.co.za/wp-content/uploads/2023/02/Muga-Reserva-Red-3.jpg'),
('Villa Rosa', 1, 18, '', 68, 18.9, 2019, 'Burgendy', 4.6, 11.8, ' A full-bodied red wine with intense flavors of dark fruits and a lingering ', 'Spring', 'Chardonney', 'https://www.luekensliquors.com/wp-content/uploads/2018/10/60379-VILLA-ROSA-MOSCATO-DASTI-w.png'),
('Viognier', 3, 13, '', 75, 28.9, 2012, 'Rhone Valley', 4.9, 13.2, 'An aromatic and fruity Viognier with apricot and floral notes.', 'Winter', 'Viognier', 'https://www.vnl.co.za/wp-content/uploads/2017/06/VNL-Viognier-NV.png'),
('Viognier Reserve', 1, 44, '', 78, 28.8, 2015, 'Rhone Valley', 6.6, 13.2, ' rich and aromatic white wine with apricot and floral notes and a creamy texture.', 'Autumn', 'Viognier', 'https://store.lismore.co.za/wp-content/uploads/2020/08/Lismore-Estate-Reserve-Viognier-1.png'),
('Zinfandel Old Vine', 1, 41, '', 65, 15.6, 2023, 'California', 6.2, 14, 'A robust and jammy red wine with flavors of blackberry, spice, and a hint of vanilla.', 'Autumn', 'Zinfadel', 'https://www.totalwine.com/dynamic/490x/media/sys_master/twmmedia/h6a/h12/13390807334942.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Accounts`
--
ALTER TABLE `Accounts`
  ADD PRIMARY KEY (`AccountID`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`UserID`,`CustomerName`);

--
-- Indexes for table `Expert`
--
ALTER TABLE `Expert`
  ADD PRIMARY KEY (`UserID`,`ExpertName`);

--
-- Indexes for table `Farm`
--
ALTER TABLE `Farm`
  ADD PRIMARY KEY (`FarmName`);

--
-- Indexes for table `FavoriteWines`
--
ALTER TABLE `FavoriteWines`
  ADD PRIMARY KEY (`UserID`,`WineTitle`);

--
-- Indexes for table `Has`
--
ALTER TABLE `Has`
  ADD PRIMARY KEY (`RetailerName`,`WineTitle`) USING BTREE;

--
-- Indexes for table `Imports`
--
ALTER TABLE `Imports`
  ADD PRIMARY KEY (`FarmName`,`WineryID`),
  ADD KEY `WineryID` (`WineryID`);

--
-- Indexes for table `Manager`
--
ALTER TABLE `Manager`
  ADD PRIMARY KEY (`UserID`,`ManagerName`);

--
-- Indexes for table `Retailer`
--
ALTER TABLE `Retailer`
  ADD PRIMARY KEY (`RetailerName`);

--
-- Indexes for table `Reviews`
--
ALTER TABLE `Reviews`
  ADD PRIMARY KEY (`UserID`,`WinesTitle`),
  ADD KEY `WineTitle4` (`WinesTitle`);

--
-- Indexes for table `Sells`
--
ALTER TABLE `Sells`
  ADD PRIMARY KEY (`WineryID`,`WineTitle`),
  ADD KEY `WineTitle3` (`WineTitle`);

--
-- Indexes for table `Species`
--
ALTER TABLE `Species`
  ADD PRIMARY KEY (`WineryID`,`SpeciesName`(50),`FarmName`),
  ADD KEY `FarmName3` (`FarmName`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`UserID`,`AccID`),
  ADD KEY `ACCID` (`AccID`);

--
-- Indexes for table `Winery`
--
ALTER TABLE `Winery`
  ADD PRIMARY KEY (`WineryID`);

--
-- Indexes for table `Wines`
--
ALTER TABLE `Wines`
  ADD PRIMARY KEY (`Title`,`WineryID`,`WineID`),
  ADD KEY `WineTitle2` (`WineryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Accounts`
--
ALTER TABLE `Accounts`
  MODIFY `AccountID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `UserID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Winery`
--
ALTER TABLE `Winery`
  MODIFY `WineryID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Customer`
--
ALTER TABLE `Customer`
  ADD CONSTRAINT `UserID` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Expert`
--
ALTER TABLE `Expert`
  ADD CONSTRAINT `UserID2` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `FavoriteWines`
--
ALTER TABLE `FavoriteWines`
  ADD CONSTRAINT `UserID3` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Has`
--
ALTER TABLE `Has`
  ADD CONSTRAINT `RetailerName1` FOREIGN KEY (`RetailerName`) REFERENCES `Retailer` (`RetailerName`);

--
-- Constraints for table `Imports`
--
ALTER TABLE `Imports`
  ADD CONSTRAINT `FArmName` FOREIGN KEY (`FarmName`) REFERENCES `Farm` (`FarmName`),
  ADD CONSTRAINT `WineryID` FOREIGN KEY (`WineryID`) REFERENCES `Winery` (`WineryID`);

--
-- Constraints for table `Manager`
--
ALTER TABLE `Manager`
  ADD CONSTRAINT `UserID5` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`);

--
-- Constraints for table `Reviews`
--
ALTER TABLE `Reviews`
  ADD CONSTRAINT `UserID4` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`),
  ADD CONSTRAINT `WineTitle4` FOREIGN KEY (`WinesTitle`) REFERENCES `Wines` (`Title`);

--
-- Constraints for table `Sells`
--
ALTER TABLE `Sells`
  ADD CONSTRAINT `WineTitle3` FOREIGN KEY (`WineTitle`) REFERENCES `Wines` (`Title`),
  ADD CONSTRAINT `WineryID2` FOREIGN KEY (`WineryID`) REFERENCES `Winery` (`WineryID`);

--
-- Constraints for table `Species`
--
ALTER TABLE `Species`
  ADD CONSTRAINT `FarmName3` FOREIGN KEY (`FarmName`) REFERENCES `Imports` (`FarmName`),
  ADD CONSTRAINT `WineryID3` FOREIGN KEY (`WineryID`) REFERENCES `Imports` (`WineryID`);

--
-- Constraints for table `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `ACCID` FOREIGN KEY (`AccID`) REFERENCES `Accounts` (`AccountID`);

--
-- Constraints for table `Wines`
--
ALTER TABLE `Wines`
  ADD CONSTRAINT `WineTitle2` FOREIGN KEY (`WineryID`) REFERENCES `Winery` (`WineryID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
