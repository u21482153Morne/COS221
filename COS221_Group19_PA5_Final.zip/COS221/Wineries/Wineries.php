<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">	 
        <script src="js/script.js"></script> 
		<title>Wineries</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <section class="intro">
            <div class="row">
				<h2>Wineries</h2>
			</div>
        </section>
            <div class="row">
                <div class="filter">
                    <label for="verified">Type: </label>
                    <select id="verified">
                        <option value="">All</option>
                        <option value="1">Verified</option>
                        <option value="0">Not Verified</option>
                    </select>
                </div>
            </div>

            <div class="row" id="winery">
            </div>
        <?php
        include('../footer.php');
        ?>
    </body>
</html>