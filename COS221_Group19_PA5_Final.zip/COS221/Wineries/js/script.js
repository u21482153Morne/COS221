document.addEventListener("DOMContentLoaded", function() {

    const filterVerified = document.getElementById("verified");

    getAllWineryInfo();

    function getAllWineryInfo(searchTerm = '') {

        const apiKey = localStorage.getItem("api");

        const data = {
            "type": "GetAllWineries",
            "limit": 50,
            "apikey": apiKey,
            "return": '*',
            "sort": "Name",
            "order": "ASC",
            "search": {
                "Verified": filterVerified.value || undefined
            }
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    if (jsonResponse.status === 'success') {
                        const response = jsonResponse.data;
                        console.log(response);
                        populateWineryInfo(response);
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not retrieve data');
                }
            }
        };

        xhr.open('POST', 'http://localhost/COS221/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

    function populateWineryInfo(wineryData) {
        const wineryList = document.getElementById('winery');
        wineryList.innerHTML = '';

        wineryData.forEach((winery, index) => {
            if (index % 3 === 0) {
                const newRow = document.createElement('div');
                newRow.className = 'row';
                wineryList.appendChild(newRow);
            }

            const currentRow = wineryList.lastElementChild;

            const wineryCard = document.createElement('div');
            wineryCard.className = 'col span-1-of-3 box';

            let verificationClass = winery.Verified ? 'verified' : 'not-verified';
            let verificationText = winery.Verified ? 'Verified' : 'Not Verified';

            wineryCard.innerHTML = `
                <img src="${winery.Image}" alt="Wine Image">
                <h3>${winery.Name}</h3>
                <p class="${verificationClass}">${verificationText}</p>
                <p>Country: ${winery.Country}</p>
                <p>Province: ${winery.Province}</p>
                <p>Town: ${winery.Town}</p>
            `;

            currentRow.appendChild(wineryCard);
        });
    }

    filterVerified.addEventListener('change', function() {
        getAllWineryInfo();
    });

});
