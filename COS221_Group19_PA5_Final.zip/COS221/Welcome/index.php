<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">	 
		<title>Global Wine Store
		</title>
    </head>
    <body>
        <header> 
			<nav class="row">
					<img src="img/logo_light.png" alt="Global Wine Store logo" class="logo">
					
			</nav>
			<div class="hero-text-box">
				<h1> Welcome to Global Wine Store </h1>
				<a class="btn" href="../LogIn/login.php">Login</a>
				<a class="btn" href="../SignUp/signup.php">Register</a>
				
			</div>
		</header>
		<footer>
			<div class="row">
                <p> Copyright &copy; 2023 by Group 19 COS221. All rights reserved. </p>
            </div>
		</footer>
    </body>
</html>