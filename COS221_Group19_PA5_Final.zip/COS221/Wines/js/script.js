document.addEventListener("DOMContentLoaded", function() {

    const searchForm = document.querySelector(".searchbar");
    const filterWineType = document.getElementById("wine-type");
    const filterSeason = document.getElementById("season");
    const sortOrder = document.getElementById("sort-by");
    const loading = document.getElementById('loading');

    getAllWineInfo();

    function getAllWineInfo(searchTerm = '') {

        const apiKey = localStorage.getItem("api");

        console.log(apiKey);
        const data = {
            "type": "GetAllWine",
            "limit": 50,
            "apikey": apiKey,
            "return": '*',
            "sort": "Price",
            "order": sortOrder.value,
            "search": {
                "Name": searchTerm,
                "Type": filterWineType.value || undefined,
                "season": filterSeason.value || undefined
            }
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    loading.style.display = 'none';
                    if (jsonResponse.status === 'success') {
                        const response = jsonResponse.data;
                        console.log(response);
                        populateWineInfo(response);
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not retrieve data');
                }
            }
        };

        xhr.open('POST', 'http://localhost/COS221/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

    // End of getAllWineInfo

    function populateWineInfo(wineData) {
        const apiKey = localStorage.getItem("api");
        const wineList = document.getElementById('wine');
        const loading = document.getElementById('loading');
        let wineCardsCreated = 0;
        wineList.innerHTML = '';
        loading.style.display = 'block';

        if (wineData.length === 0) {
            const message = document.querySelector('.message');
            message.style.display = 'block';
            loading.style.display = 'none';
        } else {
            const message = document.querySelector('.message');
            message.style.display = 'none';
        }

        wineData.forEach((wine, index) => {


            if (index % 3 === 0) {
                const newRow = document.createElement('div');
                newRow.className = 'row';
                wineList.appendChild(newRow);
            }

            const currentRow = wineList.lastElementChild;

            const wineCard = document.createElement('div');
            wineCard.className = 'col span-1-of-3 box';

            wineCard.innerHTML = `
            <img src="${wine.Image}" alt="Wine Image">
            <h3> ${wine.Name} </h3>
            <p> ${wine.Description} </p>
            <p> Type: ${wine.Type} </p>
            <p> Region: ${wine.Region} </p>
            <p> Season: ${wine.Season} </p>
            <p> Alcohol Content: ${wine.AlcoholContent} </p>
            <p> Points: ${wine.Rating} </p>
            <p> Retail Price: R${wine.Price} </p>
            <select name="rating" class="rating">
            <option value="" disabled selected>Rate</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
        `;

            const ratingSelect = wineCard.querySelector('.rating');
            ratingSelect.addEventListener('change', function() {
                const ratingValue = this.value;
                submitReview(apiKey, wine.Name, ratingValue);
            });

            currentRow.appendChild(wineCard);

            wineCardsCreated++;

            if (wineCardsCreated === wineData.length) {
                loading.style.display = 'none';
            }
        });
    }

    function submitReview(apiKey, wineName, ratingValue) {
        const data = {
            "type": "InsertReview",
            "apikey": apiKey,
            "wine": wineName,
            "rating": ratingValue,
            "return": 1
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    if (jsonResponse.status === 'success') {
                        console.log('Review submitted successfully');
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not submit review');
                }
            }
        };

        xhr.open('POST', 'http://localhost/COS221/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

        // end of populateWineInfo

        searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllWineInfo(searchTerm);
        });

        filterWineType.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllWineInfo(searchTerm);
        });

        filterSeason.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllWineInfo(searchTerm);
        });

        sortOrder.addEventListener('change',function(){
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllWineInfo(searchTerm);
        });

});