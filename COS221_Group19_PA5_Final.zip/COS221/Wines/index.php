<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <script src="js/script.js"></script> 
		<title>Wine</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <div id="loading" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 10%; height: 10%; display: flex; align-items: center; justify-content: center; z-index: 9999;">
            <img src="img/loading.svg" alt="Loading...">
        </div>
        <section class="intro">
            <div class="row">
				<h2>Wines</h2>
			</div>
        </section>
        <div class="row">
            <div class="filter">
                <label for="wine-type">Type:</label>
                <select id="wine-type">
                    <option value="">All</option>
                    <option value="Red">Red</option>
                    <option value="Rosé">Rosé</option>
                    <option value="White">White</option>
                </select>
                <label for="season">Season:</label>
                <select id="season">
                    <option value="">All</option>
                    <option value="Spring">Spring</option>
                    <option value="Summer">Summer</option>
                    <option value="Autumn">Autumn</option>
                    <option value="Winter">Winter</option>
                </select>
            </div>
            <div class="sort">
                <label for="sort-by">Sort by Price:</label>
                <select id="sort-by">
                    <option value="ASC" selected>Ascending</option>
                    <option value="DESC">Descending</option>
                </select>
            </div>
        </div>
        <div  class="row" id="wine">
        </div>
        <div class="row">
            <div class="message">No results found</div>
        </div>
        <?php
        include('../footer.php');
        ?>
    </body>
</html>