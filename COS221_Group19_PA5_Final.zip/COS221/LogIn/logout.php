<?php
    session_start();
    session_unset();
    session_destroy();

    echo '<script>
        localStorage.removeItem("api");
        window.location.href = "../LogIn/login.php";
         </script>';
    exit();
?>