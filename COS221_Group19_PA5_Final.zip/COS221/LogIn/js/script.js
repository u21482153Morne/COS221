document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector(".contact-form");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        if (validateForm()) {
            console.log("Form validation successful");
            await loginUser();
        } else {
            console.log("Form validation failed");
            alert("Please fix the errors and try again.");
        }
    });

    async function loginUser() {

        const response = await fetch("validate-login.php", {
            method: "POST",
            body: new FormData(form)
        });

        const result = await response.json();
        console.log("Result from server:", result);

        if (result.status === "success") {
            localStorage.setItem("api", result.api);
            console.log("API key stored in local storage:", result.api);
            window.location.href = "../Wines/index.php";
            alert(localStorage.getItem(("api")));
        } else {
            alert(result.message);
        }
    }
    function validateForm() {
        const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
        const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^\w\d\s:])([^\s]){8,}$/;

        if (
            !emailInput.value.trim() ||
            !passwordInput.value.trim()
        ) {
            alert("All fields are required.");
            return false;
        }

        if (!emailRegex.test(emailInput.value)) {
            alert("Invalid email address.");
            return false;
        }

        if (!passwordRegex.test(passwordInput.value)) {
            alert(
                "Password must be at least 8 characters long, contain upper and lower case letters, at least one digit and one symbol."
            );
            return false;
        }

        return true;
    }

});