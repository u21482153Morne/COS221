<?php
    // Replace the placeholders with your database credentials
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $dbname = "users_local";

    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Validate input fields
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        echo "All fields are required.";
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email address.";
        exit();
    }

    // Fetch the user's salt and hashed password from the database
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo "Email not registered.";
        exit();
    }

    $user_data = $result->fetch_assoc();
    $salt = $user_data["salt"];
    $hashed_password = $user_data["password"];

    // Verify the provided password
    if (hash("sha256", $password . $salt) !== $hashed_password) {
        echo "Incorrect password.";
        exit();
    }

    session_start();
    $_SESSION["user_id"] = $user_data["id"];
    $_SESSION["user_name"] = $user_data["name"];

    // Return the user-specific API key from the database
    echo json_encode([
        'status' => 'success',
        'api' => $user_data['api']
    ]);

    // Close the connection before ending the script
    $conn->close();
    exit();
?>