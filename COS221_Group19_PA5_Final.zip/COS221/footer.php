<footer>
    <script src="../common.js"></script>
    <div class="row">
        <p> Copyright &copy; 2023 by Group 19. All rights reserved. </p>
        <div class="theme-switcher">
            <span>Theme:</span>
            <button id="light-theme">Light</button>
            <button id="dark-theme">Dark</button>
        </div>
    </div>
</footer>