document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector(".contact-form");
    const nameInput = document.getElementById("name");
    const surnameInput = document.getElementById("surname");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        if (validateForm()) {
            form.submit();
        } else {
            alert("Please fix the errors and try again.");
        }
    });

    function validateForm() {
        const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
        const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^\w\d\s:])([^\s]){8,}$/;

        if (
            !nameInput.value.trim() ||
            !surnameInput.value.trim() ||
            !emailInput.value.trim() ||
            !passwordInput.value.trim()
        ) {
            alert("All fields are required.");
            return false;
        }

        if (!emailRegex.test(emailInput.value)) {
            alert("Invalid email address.");
            return false;
        }

        if (!passwordRegex.test(passwordInput.value)) {
            alert(
                "Password must be at least 8 characters long, contain upper and lower case letters, at least one digit and one symbol."
            );
            return false;
        }

        return true;
    }
});