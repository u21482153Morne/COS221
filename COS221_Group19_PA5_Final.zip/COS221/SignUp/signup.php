<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">
        <script src="js/script.js"></script>
        <title>Register</title>
    </head>
    <body>
    <?php
    include('../header.php');
    ?>
    <section class="intro">
        <div class="row">
            <h1>Register</h1>
        </div>
    </section>
    <section>
        <div class="row">
            <h2>Please fill in the form below</h2>
        </div>
        <div class="row">
            <form method="post" action="validate-signup.php" class="contact-form">
                <div class="row">
                    <div class="col span-1-of-3">
                        <label for="name">Name</label>
                    </div>
                    <div class="col span-2-of-3">
                        <input type="text" name="name" id="name" placeholder="Enter your first name" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-3">
                        <label for="surname">Surname</label>
                    </div>
                    <div class="col span-2-of-3">
                        <input type="text" name="surname" id="surname" placeholder="Enter your surname" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-3">
                        <label for="email">Email</label>
                    </div>
                    <div class="col span-2-of-3">
                        <input type="email" name="email" id="email" placeholder="Enter your email address" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-3">
                        <label for="password">Password</label>
                    </div>
                    <div class="col span-2-of-3">
                        <input type="password" name="password" id="password" placeholder="Choose a strong password" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col span-1-of-3"></div>
                    <div class="sbtn2 col span-2-of-3">
                        <input type="submit" class="sbtn" value="Send It!">
                    </div>
                </div>
            </form>
        </div>
    </section>
    <?php
    include('../footer.php');
    ?>
    </body>
</html>