<?php
// Replace the placeholders with your database credentials
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "users_local";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate input fields
$name = trim($_POST["name"]);
$surname = trim($_POST["surname"]);
$email = trim($_POST["email"]);
$password = trim($_POST["password"]);

if (empty($name) || empty($surname) || empty($email) || empty($password)) {
    echo "All fields are required.";
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email address.";
    exit();
}

if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^\w\d\s:])([^\s]){8,}$/", $password)) {
    echo "Invalid password.";
    exit();
}

// Check for duplicate email
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "This email address is already registered.";
    exit();
}

// Hash the password using the email as the salt
$salt = bin2hex(random_bytes(5));
$hashed_password = hash("sha256", $password . $salt);

// Insert the user data into the database
$sql = "INSERT INTO users (name, surname, email, password, salt) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $name, $surname, $email, $hashed_password, $salt);
$stmt->execute();

// Generate an API key
$api = bin2hex(random_bytes(5));

// Update the API key in the database
$sql = "UPDATE users SET api = ? WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $api, $email);
$stmt->execute();

echo "Your API key is: " . $api;

$conn->close();
?>