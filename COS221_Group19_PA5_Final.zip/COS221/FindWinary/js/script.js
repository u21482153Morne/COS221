document.addEventListener("DOMContentLoaded", function() {

  getAllWineryInfo();

  function getAllWineryInfo(searchTerm = '') {
    const apiKey = localStorage.getItem("api");

    const data = {
      "type": "GetAllWineries",
      "limit": 50,
      "apikey": apiKey,
      "return": '*',
      "search": {
           "Country": searchTerm
      }
    };

    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const jsonResponse = JSON.parse(xhr.responseText);
          if (jsonResponse.status === 'success') {
            const response = jsonResponse.data;
            console.log(response);
            populateTable(response);
          } else if (jsonResponse.status === 'error') {
            console.error(jsonResponse.data);
          } else {
            console.error('Error: Unexpected response');
          }
        } else {
          console.error('Error: Could not retrieve data');
        }
      }
    };

    xhr.open('POST', 'http://localhost/COS221/api.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
  }

  function populateTable(wineries) {
    const tableBody = document.querySelector('tbody');
    tableBody.innerHTML = '';

    wineries.forEach(function(winery) {
      const row = document.createElement('tr');
      const nameCell = document.createElement('td');
      const countryCell = document.createElement('td');
      const provinceCell = document.createElement('td');
      const townCell = document.createElement('td');

      nameCell.textContent = winery.Name;
      countryCell.textContent = winery.Country;
      provinceCell.textContent = winery.Province;
      townCell.textContent = winery.Town;

      row.appendChild(nameCell);
      row.appendChild(countryCell);
      row.appendChild(provinceCell);
      row.appendChild(townCell);

      tableBody.appendChild(row);
    });
  }

  const form = document.querySelector('.contact-form');
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const countrySelect = document.getElementById('choose-country');
    const selectedCountry = countrySelect.value;
    getAllWineryInfo(selectedCountry);
  });

});