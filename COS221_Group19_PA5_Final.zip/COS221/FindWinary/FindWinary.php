<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">
        <title>FindWineries</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <section class="intro">
            <div class="row">
				<h1>Find Wineries</h1>
			</div>
        </section>
        <section>
            <div class="row">
                <h2>Please select a country</h2>
            </div>
            <div class="row">
                <form method="post" class="contact-form">
                    <div class="row question">
                        <div>
                            <label for="choose-country"></label>
                        </div>
                        <div>
                            <select name="choose-country" id="choose-country">
                                <option value="">Any</option>
                                <option value="France">France</option>
                                <option value="United States">United States</option>
                                <option value="Spain">Spain</option>
                                <option value="Australia">Australia</option>
                                <option value="Italy">Italy</option>
                                <option value="New Zealand">New Zealand</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="row sbtn2">
                            <input type="submit" class="sbtn" value="Send it!">
                        </div>
                    </div>
                </form>
            </div>
            <div class="row">
                <h2>Results</h2>
            </div>
            <div class="row">
                <table>
                    <thead>
                        <tr>
                            <th>Winery</th>
                            <th>Country</th>
                            <th>Province</th>
                            <th>Town</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                  </table>
            </div>
        </section>
        <?php
        include('../footer.php');
        ?>
        <script src="js/script.js"></script>
    </body>
</html>