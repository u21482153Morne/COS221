// Bouchaib Chraf u20420740
/*
My Code below makes use of asynchronous calls because:
Synchronous calls would block the browser from executing any other code until the response 
is received. This can cause the browser to become unresponsive and slow down the user experience. 
Asynchronous calls would allow the browser to continue executing other code while waiting for
the response which improves performance and responsiveness. 
*/


document.addEventListener("DOMContentLoaded", function() {
    window.jsPDF = window.jspdf.jsPDF;

    const searchForm = document.querySelector(".searchbar");
    const filterEngineType = document.getElementById("engine-type");
    const filterTransmission = document.getElementById("transmission");
    const sortOrder = document.getElementById("sort-by");

    getAllCarsInfo();

    function getAllCarsInfo(searchTerm = ''){

    const data = {
        "studentnum":"u20420740",
        "type":"GetAllCars",
        "limit": 50,
        "apikey":"a9198b68355f78830054c31a39916b7f",
        "return":"*",
        "sort": "make",
        "order": sortOrder.value,
        "search": {
          "make": searchTerm,
          "engine_type": filterEngineType.value || undefined,
          "transmission": filterTransmission.value || undefined
        }
    };
    
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText).data;
          console.log(response);
          populateCarInfo(response);
        } else {
          console.error('Error: Could not retrieve data');
        }
      }
    };

    xhr.open('POST', 'https://wheatley.cs.up.ac.za/api/', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
    }

    // End of getAllCarsInfo

    function getCarImage(model, brand) {
      return new Promise(function(resolve, reject) {
        const xhr = new XMLHttpRequest();
    
        xhr.onreadystatechange = function() {
          if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
              resolve(xhr.responseText);
            } else {
              reject('Error: Could not retrieve data');
            }
          }
        };
        
        xhr.open('GET', `https://wheatley.cs.up.ac.za/api/getimage?brand=${brand}&model=${model}`, true);
        xhr.send();
      });
    }

    // End of getCarImage

    function populateCarInfo(carData) {

        const carList = document.getElementById('cars');
        const loading = document.getElementById('loading'); // load
        let carCardsCreated = 0; // load
        carList.innerHTML = '';
        loading.style.display = 'block';

        if (carData.length === 0) {
          const message = document.querySelector('.message');
          message.style.display = 'block';
          loading.style.display = 'none';
        } else {
            const message = document.querySelector('.message');
            message.style.display = 'none';
        }

        carData.forEach((car, index) => {
            if (index % 3 === 0) {
                const newRow = document.createElement('div');
                newRow.className = 'row';
                carList.appendChild(newRow);
            }
    
            const currentRow = carList.lastElementChild;

            const carCard = document.createElement('div');
            carCard.className = 'col span-1-of-3 box';
            
            getCarImage(car.model, car.make)
            .then(function(image) {
              carCard.innerHTML = `
              <img src="${image}" alt="carImage">
              <h3>${car.make + " " + car.model}</h3>
                  <p><ion-icon name="home-outline"></ion-icon> <b>Make:</b> ${car.make}</p>
                  <p><ion-icon name="car-sport-outline"></ion-icon> <b>Model:</b> ${car.model}</p>
                  <p><ion-icon name="calendar-outline"></ion-icon> <b>Year From:</b> ${car.year_from}</p>
                  <p><ion-icon name="cog-outline"></ion-icon> <b>Transmission:</b> ${car.transmission}</p>
                  <p><ion-icon name="water-outline"></ion-icon> <b>Engine Type:</b> ${car.engine_type}</p>
                  <p><ion-icon name="layers-outline"></ion-icon> <b>Body Type:</b> ${car.body_type}</p>
              `;
      
              currentRow.appendChild(carCard);

              carCardsCreated++; // load

              if (carCardsCreated === carData.length) {
                loading.style.display = 'none'; // load

                  const exportPdfBtn = document.getElementById('export-pdf-btn');
                  exportPdfBtn.addEventListener('click', function() {
                        exportPDF();
                  });
              }

            })
            .catch(function(error) {
              console.error(error);
            });
        });
        // end of for each
      }
      // end of populateCarInfo

    function exportPDF() {
        const doc = new jsPDF();
        const carCards = document.querySelectorAll('.col.span-1-of-3.box');
        let yOffset = 10;

        carCards.forEach((card, index) => {
            const cardTextElements = card.querySelectorAll('p, h3');
            const title = card.querySelector('h3').textContent;

            doc.setFontSize(16);
            doc.text(title, 10, yOffset);
            yOffset += 10;

            doc.setFontSize(12);
            cardTextElements.forEach((element) => {
                if (element.tagName === 'P') {
                    const text = element.textContent;
                    yOffset += 7;
                    doc.text(text, 15, yOffset);
                }
            });

            yOffset += 15;
            if (yOffset >= doc.internal.pageSize.getHeight() - 20) {
                doc.addPage();
                yOffset = 10;
            }
        });

        doc.save('cars.pdf');
    }


      searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
      });

      filterEngineType.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
      });

      filterTransmission.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
      });

      sortOrder.addEventListener('change',function(){
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
      });



});