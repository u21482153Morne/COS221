<!-- Bouchaib Chraf u20420740 -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/dompurify@2.3.1/dist/purify.min.js"></script>
        <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
        <script src="js/script.js"></script> 
		<title>Cars</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <div id="loading" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 10%; height: 10%; display: flex; align-items: center; justify-content: center; z-index: 9999;">
            <img src="img/loading.svg" alt="Loading...">
        </div>
        <section class="intro">
            <div class="row">
				<h2>Cars</h2>
			</div>
        </section>
        <div class="row">
            <div class="filter">
                <label for="engine-type">Engine Type:</label>
                <select id="engine-type">
                    <option value="">All</option>
                    <option value="gasoline">Gasoline</option>
                    <option value="diesel">Diesel</option>
                </select>
                <label for="transmission">Transmission:</label>
                <select id="transmission">
                    <option value="">All</option>
                    <option value="automatic">Automatic</option>
                    <option value="manual">Manual</option>
                </select>
            </div>
            <div class="sort">
                <label for="sort-by">Sort by Brand:</label>
                <select id="sort-by">
                    <option value="ASC" selected>Ascending</option>
                    <option value="DESC">Descending</option>
                </select>
            </div>
        </div>
        <div class="row">
            <button id="save-preferences-btn">Save Preferences</button>
        </div>
        <div  class="row" id="cars">
        </div>
        <div class="row">
            <div class="message">No results found</div>
        </div>
        <?php
        include('../footer.php');
        ?>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </body>
</html>