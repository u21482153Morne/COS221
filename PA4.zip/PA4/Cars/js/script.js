// Bouchaib Chraf u20420740

document.addEventListener("DOMContentLoaded", function() {

    const searchForm = document.querySelector(".searchbar");
    const filterEngineType = document.getElementById("engine-type");
    const filterTransmission = document.getElementById("transmission");
    const sortOrder = document.getElementById("sort-by");
    const loading = document.getElementById('loading');

    function getUserPreferences(callback) {
        const apiKey = localStorage.getItem('api');

        const data = {
            apikey: apiKey,
            type: 'GetUserPreferences',
            return: ["make", "model"]
        };

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://wheatley.cs.up.ac.za/u20420740/COS216/PA4/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                    callback(null, response.data);
                } else {
                    callback(response.data);
                }
            }

        };

        xhr.send(JSON.stringify(data));
    }

    getUserPreferences((error, preferences) => {
        if (error) {
            console.error('Error fetching preferences:', error);
        } else {
            getAllCarsInfo('', preferences);
        }
    });

    getAllCarsInfo();

    function getAllCarsInfo(searchTerm = '', preferences = {}) {

        const apiKey = localStorage.getItem("api");

        console.log(apiKey);
        console.log(preferences.engine_type);
        const data = {
            "type": "GetAllCars",
            "limit": 30,
            "apikey": apiKey,
            "return": ["make", "model", "year_from", "engine_type", "transmission", "body_type", "image"],
            "sort": "make",
            "order": preferences.sort || sortOrder.value,
            "search": {
                "make": searchTerm,
                "engine_type": preferences.engine_type || filterEngineType.value || undefined,
                "transmission": preferences.transmission || filterTransmission.value || undefined
            }
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    loading.style.display = 'none';
                    if (jsonResponse.status === 'success') {
                        const response = jsonResponse.data;
                        console.log(response);
                        populateCarInfo(response);
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not retrieve data');
                }
            }
        };

        xhr.open('POST', 'https://wheatley.cs.up.ac.za/u20420740/COS216/PA4/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

    // End of getAllCarsInfo

    function populateCarInfo(carData) {
        const carList = document.getElementById('cars');
        const loading = document.getElementById('loading');
        let carCardsCreated = 0;
        carList.innerHTML = '';
        loading.style.display = 'block';

        if (carData.length === 0) {
            const message = document.querySelector('.message');
            message.style.display = 'block';
            loading.style.display = 'none';
        } else {
            const message = document.querySelector('.message');
            message.style.display = 'none';
        }

        carData.forEach((car, index) => {
            if (index % 3 === 0) {
                const newRow = document.createElement('div');
                newRow.className = 'row';
                carList.appendChild(newRow);
            }

            const currentRow = carList.lastElementChild;

            const carCard = document.createElement('div');
            carCard.className = 'col span-1-of-3 box';

            carCard.innerHTML = `
            <img src="${car.image}" alt="carImage">
            <h3>${car.make + " " + car.model}</h3>
            <p><ion-icon name="home-outline"></ion-icon> Make: ${car.make}</p>
            <p><ion-icon name="car-sport-outline"></ion-icon> Model: ${car.model}</p>
            <p><ion-icon name="calendar-outline"></ion-icon> Year From:${car.year_from}</p>
            <p><ion-icon name="cog-outline"></ion-icon> Transmission: ${car.transmission}</p>
            <p><ion-icon name="water-outline"></ion-icon> Engine Type: ${car.engine_type}</p>
            <p><ion-icon name="layers-outline"></ion-icon> Body Type: ${car.body_type}</p>
            <select name="rating" class="rating">
            <option value="" disabled selected>Rate</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
        `;

            const ratingDropdown = carCard.querySelector('.rating');
            ratingDropdown.addEventListener('change', function(event) {
                const selectedRating = event.target.value;
                const userApi = localStorage.getItem("api");

                if (selectedRating !== "") {
                    addRatingToDatabase(userApi, car.make, car.model, selectedRating);
                }
            });

            currentRow.appendChild(carCard);

            carCardsCreated++;

            if (carCardsCreated === carData.length) {
                loading.style.display = 'none';
            }
        });
    }
        // end of populateCarInfo

        searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
        });

        filterEngineType.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
        });

        filterTransmission.addEventListener('change', function() {
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
        });

        sortOrder.addEventListener('change',function(){
        const searchTerm = document.getElementById("search-input").value.trim();
        getAllCarsInfo(searchTerm);
        });

    const savePreferencesBtn = document.getElementById("save-preferences-btn");
    savePreferencesBtn.addEventListener("click", saveUserPreferences);

    function saveUserPreferences() {
        const apiKey = localStorage.getItem("api");
        const engineType = document.getElementById("engine-type").value;
        const transmission = document.getElementById("transmission").value;
        const sortBy = document.getElementById("sort-by").value;

        const data = {
            type: "SavePreferences",
            apikey: apiKey,
            return: ["make", "model", "year_from", "engine_type", "transmission", "body_type", "image"],
            preferences: {
                engine_type: engineType,
                transmission: transmission,
                sort: sortBy
            }
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    if (jsonResponse.status === 'success') {
                        console.log('Preferences saved successfully');
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not save preferences');
                }
            }
        };

        xhr.open('POST', 'https://wheatley.cs.up.ac.za/u20420740/COS216/PA4/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }
    function addRatingToDatabase(api, make, model, rating) {
        const data = {
            "type": "AddRating",
            "apikey": api,
            "return": ["make", "model"],
            "make": make,
            "model": model,
            "rating": rating
        };

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    const jsonResponse = JSON.parse(xhr.responseText);
                    if (jsonResponse.status === 'success') {
                        console.log('Rating added successfully');
                    } else if (jsonResponse.status === 'error') {
                        console.error(jsonResponse.data);
                    } else {
                        console.error('Error: Unexpected response');
                    }
                } else {
                    console.error('Error: Could not add rating');
                }
            }
        };

        xhr.open('POST', 'https://wheatley.cs.up.ac.za/u20420740/COS216/PA4/api.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

});