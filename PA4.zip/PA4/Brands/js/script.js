// Bouchaib Chraf u20420740
/*
My Code below makes use of asynchronous calls because:
Synchronous calls would block the browser from executing any other code until the response 
is received. This can cause the browser to become unresponsive and slow down the user experience. 
Asynchronous calls would allow the browser to continue executing other code while waiting for
the response which improves performance and responsiveness. 
*/

document.addEventListener("DOMContentLoaded", function() {

    getAllCarsInfo();

    function getAllCarsInfo(){

    const data = {
        "studentnum":"u20420740",
        "type":"GetAllMakes",
        "apikey":"a9198b68355f78830054c31a39916b7f",
        "limit": 20
    };
    
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText).data;
          console.log(response);
          populateCarInfo(response);
        } else {
          console.error('Error: Could not retrieve data');
        }
      }
    };

    xhr.open('POST', 'https://wheatley.cs.up.ac.za/api/', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
    }

    // End of getAllCarsInfo

    function getCarImage(brand) {
      return new Promise(function(resolve, reject) {
        const xhr = new XMLHttpRequest();
    
        xhr.onreadystatechange = function() {
          if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
              resolve(xhr.responseText);
            } else {
              reject('Error: Could not retrieve data');
            }
          }
        };
        
        xhr.open('GET', `https://wheatley.cs.up.ac.za/api/getimage?brand=${brand}`, true);
        xhr.send();
      });
    }

    // End of getCarImage

    function populateCarInfo(carData) {

        const carList = document.getElementById('cars');
        const loading = document.getElementById('loading'); // load
        let carCardsCreated = 0; // load
        carList.innerHTML = '';
        loading.style.display = 'block';

        if (carData.length === 0) {
          const message = document.querySelector('.message');
          message.style.display = 'block';
          loading.style.display = 'none';
        } else {
            const message = document.querySelector('.message');
            message.style.display = 'none';
        }

        carData.forEach((car, index) => {
            if (index % 3 === 0) {
                const newRow = document.createElement('div');
                newRow.className = 'row';
                carList.appendChild(newRow);
            }
    
            const currentRow = carList.lastElementChild;

            const carCard = document.createElement('div');
            carCard.className = 'col span-1-of-3 box';
            
            getCarImage(car)
            .then(function(image) {
              carCard.innerHTML = `
              <img src="${image}" alt="BrandImage">
              <h3>${car}</h3>
              `;
      
              currentRow.appendChild(carCard);

              carCardsCreated++; // load

              if (carCardsCreated === carData.length) {
                loading.style.display = 'none'; // load
              }

            })
            .catch(function(error) {
              console.error(error);
            });
        });
        // end of for each
      }
      // end of populateCarInfo

});