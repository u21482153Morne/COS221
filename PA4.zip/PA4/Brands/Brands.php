<!-- Bouchaib Chraf u20402704 -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">	 
        <script src="js/script.js"></script> 
		<title>Brands</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <div id="loading" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 10%; height: 10%; display: flex; align-items: center; justify-content: center; z-index: 9999;">
            <img src="img/loading.svg" alt="Loading...">
        </div>
        <section class="intro">
            <div class="row">
				<h2>Brands</h2>
			</div>
        </section>
            <div class="row" id="cars">
            </div>
        <div class="row">
            <div class="message">No results found</div>
        </div>
        <?php
        include('../footer.php');
        ?>
    </body>
</html>