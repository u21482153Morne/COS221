<!-- Bouchaib Chraf u20420740 -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">
        <script src="js/script.js"></script>
		<title>Compare</title>
    </head>
    <body>
        <?php
        include('../header.php');
        ?>
        <section class="intro">
            <div class="row">
                <h2>Compare</h2>
            </div>
        </section>
        <div class = "row">
            <table>
                <thead>
                <tr>
                    <th>Feature</th>
                    <th>
                        <form>
                            <div class="search-container">
                                <input type="text" id="make1" name="make" placeholder="Vehicle make">
                                <input type="text" id="model1" name="model" placeholder="Vehicle model">
                                <button type="submit" class="blueBtn fa">&#xf002</button>
                            </div>
                        </form>
                    </th>
                    <th>
                        <form>
                            <div class="search-container">
                                <input type="text" id="make2" name="make" placeholder="Vehicle make">
                                <input type="text" id="model2" name="model" placeholder="Vehicle model">
                                <button type="submit" class="blueBtn fa">&#xf002</button>
                            </div>
                        </form>
                    </th>
                    <th>
                        <form>
                            <div class="search-container">
                                <input type="text" id="make3" name="make" placeholder="Vehicle make">
                                <input type="text" id="model3" name="model" placeholder="Vehicle model">
                                <button type="submit" class="blueBtn fa">&#xf002</button>
                            </div>
                        </form>
                    </th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Make</td>
                    <td id="make1-value"></td>
                    <td id="make2-value"></td>
                    <td id="make3-value"></td>
                </tr>
                <tr>
                    <td>Model</td>
                    <td id="model1-value"></td>
                    <td id="model2-value"></td>
                    <td id="model3-value"></td>
                </tr>
                <tr>
                    <td>Body Type</td>
                    <td id="body-type1-value"></td>
                    <td id="body-type2-value"></td>
                    <td id="body-type3-value"></td>
                </tr>
                <tr>
                    <td>Number of Seats</td>
                    <td id="number-of-seats1-value"></td>
                    <td id="number-of-seats2-value"></td>
                    <td id="number-of-seats3-value"></td>
                </tr>
                <tr>
                    <td>Number of Cylinders</td>
                    <td id="number-of-cylinders1-value"></td>
                    <td id="number-of-cylinders2-value"></td>
                    <td id="number-of-cylinders3-value"></td>
                </tr>
                <tr>
                    <td>Engine Type</td>
                    <td id="engine-type1-value"></td>
                    <td id="engine-type2-value"></td>
                    <td id="engine-type3-value"></td>
                </tr>
                <tr>
                    <td>Transmission</td>
                    <td id="transmission1-value"></td>
                    <td id="transmission2-value"></td>
                    <td id="transmission3-value"></td>
                </tr>
                <tr>
                    <td>Max Speed (km/h)</td>
                    <td id="max-speed1-value"></td>
                    <td id="max-speed2-value"></td>
                    <td id="max-speed3-value"></td>
                </tr>
                </tbody>
            </table>
        </div>
        <?php
        include('../footer.php');
        ?>
    </body>
</html>