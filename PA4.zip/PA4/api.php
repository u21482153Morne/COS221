<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Function to return a JSON error object
function jsonResponseError($message) {
    return json_encode([
        'status' => 'error',
        'timestamp' => time(),
        'data' => $message
    ]);
}

// Check if the POST data is empty
$postData = json_decode(file_get_contents('php://input'), true);
if (empty($postData)) {
    echo jsonResponseError('Error. Post parameters are missing');
    exit();
}

class Database {
    private static $instance = null;
    private $connection;

    private $servername = "137.215.98.223";
    private $username = "u20420740";
    private $password = "5OKJ752BATCBKQSGDWVNP2BMQZICWFAH";
    private $dbname = "u20420740";

    private function __construct() {
        $this->connection = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        if ($this->connection->connect_error) {
            die(json_encode([
                'status' => 'error',
                'data' => 'Connection to the database failed'
            ]));
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }

        return self::$instance;
    }

    public function query($query) {
        return $this->connection->query($query);
    }

    public function prepare($query) {
        return $this->connection->prepare($query);
    }

}

class API {

    public function validateApiKey($apikey) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE api = ?");
        $stmt->bind_param('s', $apikey);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return $row['count'] > 0;
    }

    private function fetchImageURL($make, $model) {
        $make = rawurlencode(strtolower($make));
        $model = rawurlencode(strtolower($model));
        return "https://wheatley.cs.up.ac.za/api/images/models/{$make}_{$model}.jpg";
    }

    public function getAllCars($return, $limit = 500, $sort = null, $order = 'ASC', $fuzzy = true, $search = []) {
        $db = Database::getInstance();

        // Check if 'image' is in the return array and remove it
        $returnImage = false;
        if (($key = array_search('image', $return)) !== false) {
            $returnImage = true;
            unset($return[$key]);
        }

        $columns = implode(',', $return);
        $query = "SELECT $columns FROM cars";

        $conditions = [];
        $params = '';
        $param_values = [];
        foreach ($search as $column => $value) {
            $operator = $fuzzy ? 'LIKE' : '=';
            $searchValue = $fuzzy ? '%' . $value . '%' : $value;
            $conditions[] = "$column $operator ?";
            $params .= 's';
            $param_values[] = $searchValue;
        }

        if (!empty($conditions)) {
            $query .= ' WHERE ' . implode(' AND ', $conditions);
        }

        if ($sort !== null) {
            $query .= " ORDER BY $sort $order";
        }

        $query .= " LIMIT ?";
        $params .= 'i';
        $param_values[] = $limit;

        $stmt = $db->prepare($query);
        $stmt->bind_param($params, ...$param_values);
        $stmt->execute();
        $result = $stmt->get_result();

        $cars = [];

        while ($row = $result->fetch_assoc()) {
            if ($returnImage) {
                $imageUrl = $this->fetchImageURL($row['make'], $row['model']);
                $row['image'] = $imageUrl;
            }
            $cars[] = $row;
        }

        return [
            'status' => 'success',
            'data' => $cars,
            'timestamp' => time()
        ];

    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['apikey']) || !isset($input['type']) || !isset($input['return'])) {
        echo json_encode([
            'status' => 'error',
            'data' => 'Missing required parameters.'
        ]);
        exit();
    }

    $apikey = $input['apikey'];
    $type = $input['type'];
    $return = $input['return'];

    $api = new API();

    if (!$api->validateApiKey($apikey)) {
        echo json_encode([
            'status' => 'error',
            'data' => 'Invalid API key',
            'timestamp' => time()
        ]);
        exit();
    }

    switch ($type) {
        case 'GetAllCars':
            if ($return === '*') {
                $return = [
                    'id_trim', 'make', 'model', 'generation', 'year_from', 'year_to', 'series', 'trim', 'body_type', 'number_of_seats', 'length_mm', 'width_mm', 'height_mm', 'number_of_cylinders', 'engine_type', 'drive_wheels', 'transmission', 'max_speed_km_per_h'
                ];
            }

            $limit = isset($input['limit']) ? (int)$input['limit'] : 500;
            $sort = isset($input['sort']) ? $input['sort'] : null;
            $order = isset($input['order']) && strtoupper($input['order']) === 'DESC' ? 'DESC' : 'ASC';
            $fuzzy = isset($input['fuzzy']) ? (bool)$input['fuzzy'] : true;
            $search = isset($input['search']) ? (array)$input['search'] : [];

            echo json_encode($api->getAllCars($return, $limit, $sort, $order, $fuzzy, $search) + ['timestamp' => time()]);
            break;

        case 'SavePreferences':
            if (!isset($input['preferences'])) {
                echo jsonResponseError('Error. Preferences data is missing');
                exit();
            }

            $preferences = $input['preferences'];
            $db = Database::getInstance();

            // Check if the user has existing preferences
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM preferences WHERE api = ?");
            $stmt->bind_param('i', $apikey);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            if ($row['count'] > 0) {
                // Update the user's preferences
                $stmt = $db->prepare("UPDATE preferences SET engine_type = ?, transmission = ?, sort = ? WHERE api = ?");
                $stmt->bind_param('ssss', $preferences['engine_type'], $preferences['transmission'], $preferences['sort'], $apikey);
            } else {
                // Insert the user's preferences
                $stmt = $db->prepare("INSERT INTO preferences (api, engine_type, transmission, sort) VALUES (?, ?, ?, ?)");
                $stmt->bind_param('ssss', $apikey, $preferences['engine_type'], $preferences['transmission'], $preferences['sort']);
            }

            if ($stmt->execute()) {
                echo json_encode([
                    'status' => 'success',
                    'data' => 'Preferences saved successfully',
                    'timestamp' => time()
                ]);
            } else {
                echo jsonResponseError('Error saving preferences');
            }

            break;

        case 'GetUserPreferences':
            $db = Database::getInstance();
            $stmt = $db->prepare("SELECT engine_type, transmission, sort FROM preferences WHERE api = ?");
            $stmt->bind_param('s', $apikey);
            $stmt->execute();
            $result = $stmt->get_result();
            $preferences = $result->fetch_assoc();

            if ($preferences) {
                echo json_encode([
                    'status' => 'success',
                    'data' => $preferences,
                    'timestamp' => time()
                ]);
            } else {
                echo jsonResponseError('Error fetching preferences');
            }

            break;

        case 'AddRating':
            if (!isset($input['make']) || !isset($input['model']) || !isset($input['rating'])) {
                echo jsonResponseError('Error. Make, model, or rating data is missing');
                exit();
            }

            $db = Database::getInstance();
            $stmt = $db->prepare("INSERT INTO rating (api, make, model, rating) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sssd', $apikey, $input['make'], $input['model'], $input['rating']);

            if ($stmt->execute()) {
                echo json_encode([
                    'status' => 'success',
                    'data' => 'Rating added successfully',
                    'timestamp' => time()
                ]);
            } else {
                echo jsonResponseError('Error adding rating');
            }

            break;

        default:
            echo json_encode([
                'status' => 'error',
                'data' => 'Invalid request type',
                'timestamp' => time()
            ]);
            break;
    }
} else {
    echo json_encode([
        'status' => 'error',
        'data' => 'Invalid request method',
        'timestamp' => time()
    ]);
}
?>